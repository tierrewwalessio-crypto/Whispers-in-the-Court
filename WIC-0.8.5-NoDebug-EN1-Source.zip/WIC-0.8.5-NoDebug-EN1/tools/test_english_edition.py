"""English presentation and transport checks; no game, account or network access."""
from pathlib import Path
import ast
import re
import sys
import tempfile
from unittest import TestCase, main
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools/court_brain'))
from courtbrain import actions, bundle, config, laws, migrate_ru1, nodbg_text, works
from courtbrain.nodbg_check import LONG_TEXT, SHORT_TEXT, test_law


class EnglishEdition(TestCase):
    def test_english_defaults_and_no_automatic_account_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            old = root/'WhispersInTheCourtRU-NoDebug085'
            old.mkdir()
            (old/'config.json').write_text('{"gemini_api_key":"DO-NOT-IMPORT"}')
            dest = root/'WhispersInTheCourt-NoDebug085-EN/config.json'
            with patch.object(bundle, 'config_path', return_value=dest), \
                 patch.object(config, 'discover_user_dir', return_value=None), \
                 patch.object(config, 'discover_game_dir', return_value=None), \
                 patch.object(config, 'discover_player2_port', return_value=4315):
                cfg = migrate_ru1.initialize()
            self.assertEqual(cfg.language, 'English')
            self.assertEqual(cfg.game_language, 'english')
            self.assertEqual(cfg.gemini_api_key, '')
            self.assertFalse(dest.exists())

    def test_english_law_labels_and_long_text_are_encodable(self):
        actions.set_text_language('english')
        try:
            law = test_law()
            self.assertIn('Grain Charter', laws.loc(law)['votc_law_1'])
            self.assertIn('75 gold', works.label(dict(kind='pay', amount=75, from_name='Naples'), None))
            self.assertTrue(nodbg_text.encode(laws.loc(law)))
            for text in (LONG_TEXT, SHORT_TEXT, 'ENG', 'A; "B". C:\\test\n[scope] #color $key$'):
                lines = nodbg_text.encode({'votc_out_body': text})
                self.assertTrue(lines)
                self.assertNotIn('reload switchlanguage', '\n'.join(lines))
            for stem in nodbg_text.manifest()['fallbacks']['english'].values():
                for text in stem.values():
                    self.assertIsNone(re.search('[А-Яа-яЁё]', text))
        finally:
            actions.set_text_language('english')

    def test_english_ui_and_game_strings(self):
        for name in ('ledger.py', 'drawer.py', 'chatgpt_ui.py', 'nodbg_check.py'):
            tree = ast.parse((ROOT/'tools/court_brain/courtbrain'/name).read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    # This is a user-facing list of supported language examples.
                    if 'English, Italiano' in node.value:
                        continue
                    self.assertIsNone(re.search('[А-Яа-яЁё]', node.value), (name, node.lineno))
        for file in (ROOT/'mod/WhispersInTheCourt/main_menu/localization/english').glob('*.yml'):
            for line in file.read_text(encoding='utf-8-sig').splitlines():
                if re.match(r'^\s+\w[\w.]*:\d', line):
                    self.assertIsNone(re.search('[А-Яа-яЁё]', line), file.name)


if __name__ == '__main__':
    main()
