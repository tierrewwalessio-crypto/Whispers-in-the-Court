"""One-time, non-destructive import into the isolated 0.8.5 installation."""
from pathlib import Path
import json
import shutil
import uuid


def copy_memory(source: Path, target: Path) -> bool:
    if target.exists() or not source.is_dir():
        return False
    # Build a complete copy before publishing it. Never modify the old memory.
    temp = target.with_name(target.name + '.import-' + uuid.uuid4().hex[:8])
    shutil.copytree(source, temp, ignore=shutil.ignore_patterns('__pycache__', 'binary_save_cache', '*.log'))
    temp.rename(target)
    return True


def initialize():
    """Load this edition only; never import another build's private data."""
    from . import bundle, config
    bundle.config_path().parent.mkdir(parents=True, exist_ok=True)
    return config.load()
