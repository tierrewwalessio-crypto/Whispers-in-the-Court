"""Static localization + variable fragments: no localization reload at runtime.

ASCII punctuation is represented by preloaded localization flags. It never
enters an event-target string. The GUI concatenates the fragments at display
time. Limits are explicit; an oversized scene is rejected, never truncated.
"""
from __future__ import annotations
import json
from pathlib import Path
import re
import string
from functools import lru_cache

MAX_CHUNK = 160
ASCII = {chr(i): f'vnd_c{i:03d}' for i in range(32, 127)}
ASCII.update({'\n': 'vnd_c010', '\t': 'vnd_c009'})
_SPECIAL = re.compile('([' + re.escape(string.punctuation + '\n\t') + '])')


@lru_cache(maxsize=1)
def manifest() -> dict:
    return json.loads((Path(__file__).parent / 'nodbg_manifest.json').read_text(encoding='utf-8'))


def prose(value: str) -> str:
    from .mailbox import GIST_MARK
    from .rtl import visual
    if value.startswith(GIST_MARK) and value.count(GIST_MARK) >= 2:
        _, gist, body = value.split(GIST_MARK, 2)
        value = gist + '\n\n' + body
    value = value.replace('\r\n', '\n').replace('\r', '\n')
    value = value.replace('\u00a0', ' ').replace('\u202f', ' ')
    # As in the original mod, AI prose cannot inject data-system expressions
    # or formatting. Ordinary punctuation, quotes and line breaks survive.
    value = value.translate(str.maketrans({'[': '［', ']': '］', '#': '＃', '$': '＄'}))
    return visual(value)


def fragments(value: str) -> list[str]:
    result = []
    for piece in _SPECIAL.split(prose(value)):
        if not piece:
            continue
        if piece in ASCII:
            result.append(ASCII[piece])
        elif piece.isascii() and re.fullmatch(r'[A-Za-z0-9_-]+', piece):
            # Avoid accidental localization of a raw flag such as ENG/yes.
            result.extend(ASCII[ch] for ch in piece)
        else:
            for n in range(0, len(piece), MAX_CHUNK):
                chunk = piece[n:n + MAX_CHUNK]
                # EU5 trims whitespace at the edges of a raw flag name.
                # Preserve it via static localization, including at chunk boundaries.
                leading = len(chunk) - len(chunk.lstrip(' '))
                result.extend([ASCII[' ']] * leading)
                chunk = chunk[leading:]
                trailing = len(chunk) - len(chunk.rstrip(' '))
                core = chunk.rstrip(' ')
                if core:
                    if core.isascii() and re.fullmatch(r'[A-Za-z0-9_-]+', core):
                        result.extend(ASCII[ch] for ch in core)
                    else:
                        result.append(core)
                result.extend([ASCII[' ']] * trailing)
    return result


def encode(values: dict[str, str]) -> list[str]:
    entries = manifest()['keys']
    prepared = []
    for key, value in values.items():
        if key == 'votc_loc_stamp':
            continue
        if key not in entries:
            raise ValueError(f'Unknown text field: {key}. Scene was not sent.')
        entry = entries[key]
        parts = fragments(str(value))
        if len(parts) > entry['capacity']:
            raise ValueError(f"Text {key} is too long ({len(parts)} fragments, limit {entry['capacity']}). Scene was not sent.")
        prepared.append((entry, parts))
    lines = []
    for entry, parts in prepared:
        ident, capacity = entry['id'], entry['capacity']
        # Initialize the entire fixed display region. This clears stale tails
        # after a short message replaces a longer one, including after a load.
        for index in range(capacity):
            part = parts[index] if index < len(parts) else 'vnd_empty'
            if any(ch in part for ch in ':.;"\\\n\r{}#[]$<>'):
                raise ValueError('Invalid character in a transport fragment.')
            lines.append(f'set_global_variable = {{ name = vnd_{ident}_{index} value = "flag:{part}" }}')
        lines.append(f'set_global_variable = {{ name = vnd_{ident}_ready value = yes }}')
    return lines


def registry_values(names, places) -> dict[str, str]:
    values = {}
    for n, item in names.items.items():
        values[f'votc_cname_{n}'] = item.get('name') or ''
        values[f'votc_cname_{n}_ADJ'] = item.get('adj') or item.get('name') or ''
    for n, item in places.items.items():
        values[f'votc_lname_{n}'] = item.get('name') or ''
    return values
