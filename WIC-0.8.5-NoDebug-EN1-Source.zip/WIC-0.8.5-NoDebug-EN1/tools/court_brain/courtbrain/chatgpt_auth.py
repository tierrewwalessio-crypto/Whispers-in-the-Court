"""Public-client Sign in with ChatGPT; separate, Windows-protected credentials.

Protocol: developers.openai.com/siwc/token-sharing-open-source (2026-10-11).
Never imports credentials from Codex, browser profiles or another application.
"""
from __future__ import annotations

import base64
from contextlib import contextmanager
import ctypes
from ctypes import wintypes
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser

ISSUER = "https://auth.openai.com"
AUTHORIZE = ISSUER + "/api/accounts/authorize"
TOKEN = ISSUER + "/api/accounts/oauth/token"
RESOURCE = "https://api.openai.com/v1"
PLAN_SCOPE = "chatgpt.tokens.use.direct"
SCOPES = "openid profile email offline_access resource.invoke " + PLAN_SCOPE
_LOCK = threading.RLock()


class AuthError(RuntimeError):
    pass


def request_json(url, fields=None, *, bearer=None, timeout=30):
    data = urllib.parse.urlencode(fields).encode() if fields is not None else None
    headers = {"Accept": "application/json"}
    if fields is not None:
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if bearer:
        headers["Authorization"] = "Bearer " + bearer
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read(4 * 1024 * 1024)
        return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        # Do not surface arbitrary bodies: identity responses can contain credentials.
        raise AuthError(f'ChatGPT: HTTP {exc.code}. Check service access and sign in again.') from None
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        raise AuthError('Could not reach ChatGPT. Check your connection and try again.') from None


def _protect(data: bytes, decrypt=False) -> bytes:
    if os.name != "nt":
        raise AuthError('This build uses Windows protection for sign-in data and requires Windows.')
    class Blob(ctypes.Structure):
        _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]
    buf = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    source = Blob(len(data), buf)
    dest = Blob()
    crypt = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    if decrypt:
        fn = crypt.CryptUnprotectData
        fn.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        ok = fn(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(dest))
    else:
        fn = crypt.CryptProtectData
        fn.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.c_void_p, ctypes.c_void_p,
                       ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        ok = fn(ctypes.byref(source), "Whispers in the Court ChatGPT", None, None, None, 1, ctypes.byref(dest))
    if not ok:
        raise AuthError('Windows could not decrypt or protect the ChatGPT sign-in data.')
    try:
        return ctypes.string_at(dest.data, dest.size)
    finally:
        kernel.LocalFree(dest.data)


class AccountStore:
    def __init__(self, path: Path | None = None):
        self.path = path or Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "WhispersInTheCourt-NoDebug085-EN" / "chatgpt.dpapi"

    @contextmanager
    def locked(self):
        """Serialize token rotation across UI, workers and program instances."""
        with _LOCK:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.path.with_suffix(".lock"), "a+b") as handle:
                handle.seek(0, 2)
                if handle.tell() == 0:
                    handle.write(b"0")
                    handle.flush()
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt
                    deadline = time.monotonic() + 40
                    while True:
                        try:
                            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                            break
                        except OSError:
                            if time.monotonic() > deadline:
                                raise AuthError('Another window is refreshing ChatGPT sign-in. Try again.')
                            time.sleep(.1)
                try:
                    yield
                finally:
                    if os.name == "nt":
                        handle.seek(0)
                        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)

    def _read(self):
        if not self.path.exists():
            return {"host_id": "urn:uuid:" + str(uuid.uuid4()), "accounts": {}}
        try:
            return json.loads(_protect(self.path.read_bytes(), decrypt=True))
        except (ValueError, OSError):
            raise AuthError('Could not read the saved ChatGPT sign-in.') from None

    def _write(self, data):
        raw = _protect(json.dumps(data, ensure_ascii=False).encode("utf-8"))
        temp = self.path.with_suffix(".tmp")
        temp.write_bytes(raw)
        temp.replace(self.path)

    def snapshot(self):
        with self.locked():
            data = self._read()
            if not self.path.exists():
                self._write(data)
            return data

    def accounts(self):
        return [{"id": key, "label": f"{a.get('email') or 'ChatGPT'} · {key[-8:]}",
                 "connected": bool(a.get("access_token"))}
                for key, a in self.snapshot()["accounts"].items()]

    def save_account(self, key, record):
        with self.locked():
            data = self._read()
            data["accounts"][key] = record
            self._write(data)

    def access_token(self, key):
        with self.locked():
            data = self._read()
            a = data["accounts"].get(key)
            if not a or not a.get("access_token"):
                raise AuthError('Sign in to ChatGPT in AI settings.')
            if PLAN_SCOPE not in a.get("scopes", []):
                raise AuthError('Plan access was not granted. Sign in again and allow access to your plan limits.')
            if time.time() >= a.get("expires_at", 0) - 90:
                if not a.get("refresh_token"):
                    raise AuthError('ChatGPT sign-in has expired. Sign in again.')
                token = request_json(TOKEN, {"grant_type": "refresh_token", "client_id": key,
                                            "refresh_token": a["refresh_token"], "resource": RESOURCE})
                update_tokens(a, token, refresh=True)
                self._write(data)
                if PLAN_SCOPE not in a["scopes"]:
                    raise AuthError('ChatGPT no longer allows plan access. Sign in again.')
            return a["access_token"]

    def sign_out(self, key):
        with self.locked():
            data = self._read()
            a = data["accounts"].get(key)
            if not a:
                return True
            confirmed = not a.get("refresh_token")
            if not confirmed:
                try:
                    discovery = request_json(ISSUER + "/.well-known/openid-configuration")
                    endpoint = discovery.get("revocation_endpoint", "")
                    parsed = urllib.parse.urlparse(endpoint)
                    if parsed.scheme != "https" or parsed.netloc != "auth.openai.com":
                        raise AuthError('Unknown logout address.')
                    for attempt in range(2):
                        try:
                            request_json(endpoint, {"token": a["refresh_token"], "token_type_hint": "refresh_token",
                                                    "client_id": key})
                            confirmed = True
                            break
                        except AuthError:
                            if attempt == 0:
                                time.sleep(1)
                except AuthError:
                    pass
            for field in ("access_token", "refresh_token", "id_token", "expires_at", "scopes"):
                a.pop(field, None)
            self._write(data)
            return confirmed


def update_tokens(record, token, *, refresh=False):
    if not isinstance(token.get("access_token"), str) or not token["access_token"]:
        raise AuthError('ChatGPT did not issue access credentials. Sign in again.')
    if str(token.get("token_type", "Bearer")).lower() != "bearer":
        raise AuthError('Unknown ChatGPT access type.')
    record["access_token"] = token["access_token"]
    for field in ("refresh_token", "id_token"):
        if token.get(field):
            record[field] = token[field]
    record["scopes"] = token["scope"].split() if "scope" in token else record.get("scopes", []) if refresh else []
    record["expires_at"] = time.time() + max(0, int(token.get("expires_in", 0)))


def validate_identity(encoded, client_id, nonce):
    import jwt
    try:
        key = jwt.PyJWKClient(ISSUER + "/.well-known/jwks.json", timeout=30).get_signing_key_from_jwt(encoded)
        claims = jwt.decode(encoded, key.key, algorithms=["RS256"], issuer=ISSUER,
                            audience=client_id, options={"require": ["iss", "aud", "exp", "sub", "nonce"]})
        if not secrets.compare_digest(str(claims["nonce"]), nonce):
            raise AuthError('The sign-in response does not match the request. Sign in again.')
        return claims
    except jwt.PyJWTError:
        raise AuthError('Could not verify the authenticity of the ChatGPT response. Sign in again.') from None


def sign_in(store: AccountStore, account_id="", *, open_browser=webbrowser.open, cancel=None):
    snapshot = store.snapshot()
    old = snapshot["accounts"].get(account_id) if account_id else None
    if account_id and not old:
        raise AuthError('Saved account not found.')
    state, nonce, verifier = (secrets.token_urlsafe(48) for _ in range(3))
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
    result = {}

    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            self.request.settimeout(3)
            super().setup()

        def log_message(self, *args):
            pass  # the callback contains credentials

        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            valid = parsed.path == "/auth/callback" and query.get("state") == [state]
            valid = valid and all(len(v) == 1 for v in query.values()) and not result
            self.send_response(200 if valid else 400)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if valid:
                result.update({k: v[0] for k, v in query.items()})
            try:
                self.wfile.write(('Response received. Return to Whispers in the Court; sign-in verification is continuing.'
                                  if valid else 'This request does not match the expected sign-in.').encode())
            except OSError:
                pass

    server = HTTPServer(("127.0.0.1", 0), Handler)
    server.timeout = .5
    redirect = f"http://127.0.0.1:{server.server_port}/auth/callback"
    params = {"client_id": account_id or "dynamic_agent_client", "ext_agent_host_id": snapshot["host_id"],
              "response_type": "code", "redirect_uri": redirect, "scope": SCOPES, "resource": RESOURCE,
              "state": state, "nonce": nonce, "code_challenge_method": "S256", "code_challenge": challenge}
    if old:
        if old.get("id_token"):
            params["id_token_hint"] = old["id_token"]
        if old.get("email"):
            params["login_hint"] = old["email"]
    else:
        params["agent_name_hint"] = "Whispers in the Court"
    try:
        if not open_browser(AUTHORIZE + "?" + urllib.parse.urlencode(params)):
            raise AuthError('Could not open a browser for ChatGPT sign-in.')
        end = time.monotonic() + 300
        while not result and time.monotonic() < end and not (cancel and cancel.is_set()):
            server.handle_request()
    finally:
        server.server_close()
    if not result:
        raise AuthError('Sign-in was cancelled or timed out. Try again.')
    if result.get("error"):
        raise AuthError('ChatGPT sign-in was not completed or permission was declined.')
    issued = result.get("client_id") or account_id
    if not issued or issued == "dynamic_agent_client" or (account_id and issued != account_id):
        raise AuthError('ChatGPT did not confirm app registration.')
    if not result.get("code"):
        raise AuthError('ChatGPT did not return a sign-in code.')
    if not old:
        # Preserve the issued registration if exchange fails; never activate it before ID validation.
        store.save_account(issued, {"client_id": issued, "issuer": ISSUER, "subject": ""})
    token = request_json(TOKEN, {"grant_type": "authorization_code", "client_id": issued,
                                "code": result["code"], "code_verifier": verifier,
                                "redirect_uri": redirect, "resource": RESOURCE})
    claims = validate_identity(token.get("id_token", ""), issued, nonce)
    if old and old.get("subject") and old["subject"] != claims["sub"]:
        raise AuthError('A different account was selected. Use the add-account button.')
    record = {"subject": claims["sub"], "email": claims.get("email", ""), "client_id": issued, "issuer": ISSUER}
    update_tokens(record, token)
    store.save_account(issued, record)
    return issued
