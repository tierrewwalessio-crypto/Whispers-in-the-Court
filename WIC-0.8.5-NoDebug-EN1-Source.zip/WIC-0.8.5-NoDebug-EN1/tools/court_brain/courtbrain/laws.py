"""Custom laws: laws of the realm written at the ruler's request, enacted in the game's own laws window.

The ruler asks for laws on a matter - work and wages, the poor, the guilds, the roads, the press - and the
AI writes ONE law with two to four options, each a real choice: what the realm gains, what it pays, where
its values drift. The mod shows them as real laws of the game (tools/gen_laws.py): the player picks the
option in the laws window, pays the game's own price, waits for it to come into force.

Balanced here, the same way every time:
* the first option is the realm's custom as it stands - no gain, no cost: the game may set it at once,
  and nothing must ever come for free;
* every other option is a trade-off: what it gains is about what it costs (gains minus costs between -1
  and +1, in strengths 1-3), at most two of each, never the same lever both ways;
* a drift of the realm's values (towards free subjects, serfdom, centralisation...) is neither gain nor cost;
* four laws at most; a new law on a matter already regulated replaces it.
"""

from __future__ import annotations

import re
from typing import Any

from . import actions as A

SLOTS = 4
OPTIONS = 4
STRENGTH_WORD = {1: "minor", 2: "moderate", 3: "major"}
VALUE_WORD = {1: "slowly", 2: "steadily"}
# The realm's values a law may push towards (tools/gen_laws.py VALUES).
VALUES = ("centralization", "decentralization", "serfdom", "free_subjects", "aristocracy", "plutocracy",
          "traditionalist", "innovative", "spiritualist", "humanist", "absolutism", "liberalism",
          "mercantilism", "free_trade", "land", "naval", "quality", "quantity", "belligerent", "conciliatory",
          "capital_economy", "traditional_economy", "communalism", "individualism", "offensive", "defensive",
          "outward", "inward", "jurisprudence", "mysticism")
AREAS = tuple(A.POLICY_AREAS)

RULES = """
LAWS OF THE REALM ("laws") - when the ruler asks for laws on a matter
Only when the RULER plainly asks for laws, a statute, an ordinance or rules on a
matter of the realm ("laws on working conditions", "an ordinance for the poor",
"rules for the guilds", "a statute of labourers"): write ONE law that the ruler
will then enact in the realm's laws window, choosing one of its options.
- "name": the law's name as this realm and AGE would call it (a statute, an
  ordinance, an assize, a code - never a modern term in a medieval court);
  "about": one sentence on the matter it settles.
- "options": two to four real ways of settling it, each with a name and a short
  description in the voice of the age. The FIRST is always the realm's custom as
  it stands now (things left as they are): no gains, no costs.
- Each other option is a TRADE-OFF, as such laws really are: "gains" (one or two
  levers of the state it helps, strength 1-3) and "costs" (one or two it weighs on,
  1-3) about equal in weight - who gains and who pays, really (higher wages for
  the peasants: their favour and production up, the nobles' favour and the
  Crown's taxes down). Never the same lever both ways.
- "values": where it pushes the realm's character, if anything (towards free
  subjects or serfdom, centralisation, humanism...), strength 1-2.
- Fit THIS realm and age: what such a realm could really regulate, enforce and
  afford. A law the realm cannot enforce (no officials, an order in revolt) is
  weak in its gains.
- To abolish a law of the realm in force: "action": "repeal" with its name (see
  CUSTOM LAWS OF THE REALM).
""".strip()


def schema() -> dict[str, Any]:
    lever = {"type": "object", "additionalProperties": False, "required": ["area", "strength"],
             "properties": {"area": {"type": "string", "enum": list(AREAS)},
                            "strength": {"type": "integer", "minimum": 1, "maximum": 3}}}
    drift = {"type": "object", "additionalProperties": False, "required": ["value", "strength"],
             "properties": {"value": {"type": "string", "enum": list(VALUES)},
                            "strength": {"type": "integer", "minimum": 1, "maximum": 2}}}
    option = {"type": "object", "additionalProperties": False,
              "required": ["name", "desc", "gains", "costs", "values"],
              "properties": {
                  "name": {"type": "string", "description": "The option's name, max 50 characters."},
                  "desc": {"type": "string", "description": "What it orders, one or two sentences, in the voice of "
                                                            "the age."},
                  "gains": {"type": "array", "items": lever, "maxItems": 2},
                  "costs": {"type": "array", "items": lever, "maxItems": 2},
                  "values": {"type": "array", "items": drift, "maxItems": 1}}}
    return {
        "type": "array", "maxItems": 1,
        "description": "A law of the realm the ruler asked for, or one repealed. Usually empty. See LAWS OF THE REALM.",
        "items": {"type": "object", "additionalProperties": False,
                  "required": ["action", "name", "about", "options"],
                  "properties": {
                      "action": {"type": "string", "enum": ["create", "repeal"]},
                      "name": {"type": "string", "description": "The law's name, max 50 characters."},
                      "about": {"type": "string", "description": "One sentence: the matter it settles."},
                      "options": {"type": "array", "items": option, "maxItems": OPTIONS}}},
    }


def _t(value: Any, limit: int) -> str:
    text = " ".join(str(value or "").split()).strip(" \"'")
    return text if len(text) <= limit else text[:limit - 1].rsplit(" ", 1)[0] + "…"


def _words(text: str) -> set[str]:
    return {w for w in re.findall(r"\w{4,}", (text or "").lower())}


def find(active: dict[int, dict[str, Any]], name: str, about: str = "") -> int:
    """The slot of a law in force on the same matter (by its name or its matter), or 0."""
    mine = _words(name) | _words(about)
    for slot, law in active.items():
        other = _words(law.get("name", "")) | _words(law.get("about", ""))
        if mine and other and len(mine & other) / min(len(mine), len(other)) >= 0.5:
            return slot
    return 0


def _levers(raw: Any) -> list[dict[str, Any]]:
    out, seen = [], set()
    for x in raw if isinstance(raw, list) else []:
        if not isinstance(x, dict) or x.get("area") not in AREAS or x["area"] in seen:
            continue
        seen.add(x["area"])
        out.append({"area": x["area"], "strength": max(1, min(3, int(x.get("strength") or 1)))})
    return out[:2]


def _balance(gains: list[dict[str, Any]], costs: list[dict[str, Any]]) -> None:
    """A law is a trade-off: gains minus costs between -1 and +1 (the largest is lowered first)."""
    def net() -> int:
        return sum(g["strength"] for g in gains) - sum(c["strength"] for c in costs)
    while net() > 1:
        top = max(gains, key=lambda g: g["strength"])
        top["strength"] -= 1
        if top["strength"] < 1:
            gains.remove(top)
    while net() < -1:
        top = max(costs, key=lambda c: c["strength"])
        top["strength"] -= 1
        if top["strength"] < 1:
            costs.remove(top)


def validate(raw: Any, active: dict[int, dict[str, Any]]) -> tuple[dict[str, Any] | None, str]:
    """A law the AI wrote, made sound: (law, "") or (None, why not)."""
    if not isinstance(raw, dict) or raw.get("action") not in ("create", "repeal"):
        return None, ""
    name, about = _t(raw.get("name"), 50), _t(raw.get("about"), 200)
    if not name:
        return None, "a law needs a name"
    slot = find(active, name, about)
    if raw["action"] == "repeal":
        if not slot:
            return None, f"no law of the realm called {name!r} is in force"
        return {"action": "repeal", "slot": slot, "name": active[slot].get("name", name)}, ""
    options = []
    for o in [x for x in raw.get("options") or [] if isinstance(x, dict)][:OPTIONS]:
        oname = _t(o.get("name"), 50)
        if not oname or any(oname.lower() == p["name"].lower() for p in options):
            continue
        gains, costs = _levers(o.get("gains")), _levers(o.get("costs"))
        costs = [c for c in costs if c["area"] not in {g["area"] for g in gains}]
        values = [{"value": v["value"], "strength": max(1, min(2, int(v.get("strength") or 1)))}
                  for v in (o.get("values") or []) if isinstance(v, dict) and v.get("value") in VALUES][:1]
        if not options:
            gains, costs = [], []             # the custom as it stands: the game may set it at once, for free
        else:
            _balance(gains, costs)
        options.append({"name": oname, "desc": _t(o.get("desc"), 300), "gains": gains, "costs": costs,
                        "values": values})
    if len(options) < 2:
        return None, "a law needs at least two options: the custom as it stands and another way"
    if not any(o["gains"] or o["costs"] or o["values"] for o in options[1:]):
        return None, "none of its options would change anything"
    if not slot:
        slot = next((s for s in range(1, SLOTS + 1) if s not in active), 0)
        if not slot:
            return None, (f"{SLOTS} laws of the realm already stand: one must be repealed first ("
                          + "; ".join(law.get("name", "") for law in active.values()) + ")")
    return {"action": "create", "slot": slot, "name": name, "about": about, "options": options,
            "replaces": active.get(slot, {}).get("name", "")}, ""


def effects_text(o: dict[str, Any]) -> str:
    """What an option does, in plain words (for its tooltip and the court)."""
    if A._TEXT_LANGUAGE == "russian":
        from .ru_laws import effects_text as translated
        return translated(o)
    parts = [f"{A.POLICY_TEXT.get(g['area'], g['area'])} +{STRENGTH_WORD[g['strength']]}" for g in o["gains"]]
    parts += [f"{A.POLICY_TEXT.get(c['area'], c['area'])} -{STRENGTH_WORD[c['strength']]}" for c in o["costs"]]
    parts += [f"the realm drifts {VALUE_WORD[v['strength']]} towards {v['value'].replace('_', ' ')}"
              for v in o["values"]]
    return "; ".join(parts) if parts else "no change: things stay as they are"


def loc(law: dict[str, Any]) -> dict[str, str]:
    """The law's text for the game: names, descriptions, what each option does."""
    if A._TEXT_LANGUAGE == "russian":
        from .ru_laws import loc as translated
        return translated(law)
    s = law["slot"]
    out = {f"votc_law_{s}": law["name"],
           f"votc_law_{s}_desc": (law.get("about") or "") + " (Written at the ruler's command.)"}
    for i in range(1, OPTIONS + 1):
        if i <= len(law["options"]):
            o = law["options"][i - 1]
            effects = effects_text(o)
            out[f"votc_law_{s}_p{i}"] = o["name"]
            out[f"votc_law_{s}_p{i}_desc"] = f"{o['desc']}\n\nWhen fully in force: {effects}."
            out[f"votc_law_{s}_p{i}_tt"] = f"When fully in force: {effects}."
    return out


def _vars(law: dict[str, Any]) -> list[str]:
    s = law["slot"]
    out = []
    for i, o in enumerate(law["options"], start=1):
        out.append(f"votc_lw{s}_p{i}_on")
        out += [f"votc_lw{s}_p{i}_{x['area']}" for x in o["gains"] + o["costs"]]
        out += [f"votc_lw{s}_p{i}_v_{v['value']}" for v in o["values"]]
    return out


def script(law: dict[str, Any], old: dict[str, Any] | None) -> list[str]:
    """The game's lines: the old law's variables cleared, the new one's set, an option already in force
    given its new effects at once."""
    s = law["slot"]
    lines = [f"remove_variable = {v}" for v in (_vars(old) if old else [])]
    lines += [f"remove_variable = votc_lw{s}_p{i}_on" for i in range(1, OPTIONS + 1)]
    lines.append(f"votc_law_clear_{s} = yes")
    if law["action"] == "repeal":
        lines.append(f"remove_variable = votc_lw{s}_on")
        return lines
    lines.append(f"set_variable = {{ name = votc_lw{s}_on value = 1 }}")
    for i, o in enumerate(law["options"], start=1):
        lines.append(f"set_variable = {{ name = votc_lw{s}_p{i}_on value = 1 }}")
        lines += [f"set_variable = {{ name = votc_lw{s}_p{i}_{g['area']} value = {g['strength']} }}" for g in o["gains"]]
        lines += [f"set_variable = {{ name = votc_lw{s}_p{i}_{c['area']} value = -{c['strength']} }}"
                  for c in o["costs"]]
        lines += [f"set_variable = {{ name = votc_lw{s}_p{i}_v_{v['value']} value = {v['strength']} }}"
                  for v in o["values"]]
    # an option of this law already in force (a law rewritten): its new effects at once
    lines += [f"if = {{ limit = {{ has_policy = votc_law_{s}_p{i} }} votc_law_apply = {{ law = {s} opt = {i} }} }}"
              for i in range(1, len(law["options"]) + 1)]
    return lines


def label(law: dict[str, Any]) -> str:
    if A._TEXT_LANGUAGE == "russian":
        from .ru_laws import label as translated
        return translated(law)
    if law["action"] == "repeal":
        return f"⚖ Law repealed: {law['name']}"
    return (f"⚖ New law of the realm: {law['name']} ({len(law['options'])} options) - choose one in the "
            f"laws window (socioeconomic laws)")


def brief(active: dict[int, dict[str, Any]]) -> str:
    if not active:
        return ""
    lines = ["CUSTOM LAWS OF THE REALM (written at the ruler's command; the ruler chooses the option in force in "
             "the laws window):"]
    for slot, law in sorted(active.items()):
        opts = "; ".join(f"{o['name']} ({effects_text(o)})" for o in law.get("options") or [])
        lines.append(f"- {law.get('name', '')}: {law.get('about', '')} Options: {opts}")
    return "\n".join(lines)
