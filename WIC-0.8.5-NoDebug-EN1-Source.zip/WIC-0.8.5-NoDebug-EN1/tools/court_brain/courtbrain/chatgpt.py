"""ChatGPT subscription transport: OAuth + public Responses API, no API-key fallback."""
from __future__ import annotations

import json
import time
import urllib.request
import urllib.error

from .chatgpt_auth import AccountStore, AuthError, RESOURCE, request_json
from .player2 import Player2Client, Player2Error, Usage


def response_payload(messages, schema, model, schema_name):
    # This subscription route rejects temperature, max_output_tokens and system items.
    return {"model": model, "store": False, "stream": True,
            "input": [{"role": "developer" if m["role"] == "system" else m["role"],
                       "content": m["content"]} for m in messages],
            "text": {"format": {"type": "json_schema", "name": schema_name, "strict": True, "schema": schema}}}


def read_response(stream):
    """Read SSE through the terminal event. A partial JSON object is never success."""
    data = []
    size = 0
    # Some subscription responses omit output from response.completed. Keep text
    # from the stream, but release it only after successful terminal completion.
    streamed = {}

    def save_content(index, content):
        for offset, part in enumerate(content):
            if part.get("type") == "refusal":
                raise Player2Error('ChatGPT declined this request.')
            if part.get("type") == "output_text":
                streamed[(index, offset)] = part.get("text", "")

    for raw in stream:
        size += len(raw)
        if size > 16 * 1024 * 1024:
            raise Player2Error('The ChatGPT response is too large.')
        line = raw.decode("utf-8").rstrip("\r\n")
        if line.startswith("data:"):
            data.append(line[5:].lstrip())
        elif not line and data:
            block = "\n".join(data)
            data = []
            if block == "[DONE]":
                break
            try:
                event = json.loads(block)
            except ValueError:
                raise Player2Error('ChatGPT returned a malformed response stream.') from None
            kind = event.get("type")
            key = (event.get("output_index", 0), event.get("content_index", 0))
            if kind == "response.output_text.delta":
                streamed[key] = streamed.get(key, "") + event.get("delta", "")
            elif kind == "response.output_text.done":
                streamed[key] = event.get("text", "")
            elif kind == "response.output_item.done":
                item = event.get("item") or {}
                if item.get("type") == "message":
                    save_content(event.get("output_index", 0), item.get("content", []))
            elif kind in ("response.refusal.delta", "response.refusal.done"):
                raise Player2Error('ChatGPT declined this request.')
            if kind in ("response.failed", "response.incomplete", "error"):
                error = event.get("response", {}).get("error") or event.get("error") or {}
                code = error.get("code", kind) if isinstance(error, dict) else kind
                # Only expose machine codes, never echoed prompts or credentials.
                safe = str(code) if all(c.isalnum() or c in "_.-" for c in str(code)) else kind
                raise Player2Error(f'ChatGPT did not complete the response ({safe}). Check your plan limits and try again.')
            if kind == "response.completed":
                response = event.get("response") or {}
                if response.get("status") != "completed":
                    raise Player2Error('ChatGPT did not confirm response completion.')
                parts = []
                for item in response.get("output", []):
                    if item.get("type") == "message":
                        for content in item.get("content", []):
                            if content.get("type") == "refusal":
                                raise Player2Error('ChatGPT declined this request.')
                            if content.get("type") == "output_text":
                                parts.append(content.get("text", ""))
                text = "".join(parts) or "".join(streamed[key] for key in sorted(streamed))
                if not text:
                    raise Player2Error('ChatGPT completed the request but returned no text. Try the check again.')
                return text, response
    raise Player2Error('The ChatGPT connection ended before the response completed. No consequences were applied.')


class ChatGPTClient(Player2Client):
    NAME = "ChatGPT"

    def __init__(self, cfg, voice, *, store=None):
        super().__init__(RESOURCE, "", timeout=cfg.request_timeout_s, max_tokens=cfg.max_tokens)
        self.store = store or AccountStore()
        self.account_id = cfg.chatgpt_account
        self.model = cfg.chatgpt_model
        self.voice = voice

    def model_catalog(self):
        try:
            token = self.store.access_token(self.account_id)
            data = request_json(RESOURCE + "/models", bearer=token, timeout=self.timeout)
        except AuthError as exc:
            self.up = False
            raise Player2Error(str(exc)) from None
        catalog = [{"slug": m["slug"], "display_name": m.get("display_name") or m["slug"]}
                   for m in data.get("models", []) if m.get("visibility") == "list" and m.get("slug")]
        if not catalog:
            raise Player2Error('ChatGPT did not provide any available models for this account.')
        return catalog

    def check(self):
        try:
            models = self.model_catalog()
            if not self.model:
                raise Player2Error('Select a ChatGPT model in AI settings.')
            if self.model not in {m["slug"] for m in models}:
                raise Player2Error('The selected model is unavailable. Refresh the model list in AI settings.')
            self.up = True
            return True, f'account connected; model {self.model} (generation not tested yet)'
        except Player2Error as exc:
            self.up = False
            return False, str(exc)

    def health(self):
        ok, _ = self.check()
        return {"provider": "chatgpt"} if ok else None

    def complete_json(self, messages, schema, *, schema_name="scene", temperature=None,
                      max_tokens=None, retries=2, json_object=False):
        import jsonschema
        if not self.model:
            raise Player2Error('Select a ChatGPT model in AI settings.')
        try:
            token = self.store.access_token(self.account_id)
        except AuthError as exc:
            self.up = False
            raise Player2Error(str(exc)) from None
        payload = response_payload(messages, schema, self.model, schema_name)
        request = urllib.request.Request(RESOURCE + "/responses", data=json.dumps(payload).encode("utf-8"),
                                         headers={"Authorization": "Bearer " + token,
                                                  "Content-Type": "application/json", "Accept": "text/event-stream"})
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as stream:
                text, response = read_response(stream)
        except urllib.error.HTTPError as exc:
            self.up = False
            hint = {400: 'the model rejected the request format', 401: 'sign in again', 403: 'access denied',
                    429: 'plan limit reached; wait for it to reset'}.get(exc.code, 'try again later')
            raise Player2Error(f"ChatGPT: HTTP {exc.code} — {hint}.", status=exc.code) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            self.up = False
            raise Player2Error('The ChatGPT connection was interrupted. Check your connection and try again.') from None
        usage = response.get("usage") or {}
        self.last_usage = Usage(int(usage.get("input_tokens", 0)), int(usage.get("output_tokens", 0)),
                                int(usage.get("total_tokens", 0)))
        self.last_model = response.get("model", self.model)
        if self.on_usage:
            self.on_usage(schema_name, self.last_usage.prompt_tokens, self.last_usage.completion_tokens, 0)
        if self.on_meter:
            self.on_meter([{"t": time.time(), "kind": schema_name, "model": self.last_model,
                            "in": self.last_usage.prompt_tokens, "out": self.last_usage.completion_tokens,
                            "try": 1, "joules": None}])
        try:
            result = json.loads(text)
            jsonschema.validate(result, schema)
        except (ValueError, jsonschema.ValidationError, jsonschema.SchemaError):
            raise Player2Error("The ChatGPT response does not match the mod's format. No consequences were applied.") from None
        if not isinstance(result, dict):
            raise Player2Error('ChatGPT returned an invalid response type.')
        self.up = True
        return result

    def balance(self):
        return None

    def start_health_pings(self, interval=60.):
        pass  # no polling or metered background inference

    def voices(self):
        return self.voice.voices()

    def speak(self, text, voice_id=""):
        self.voice.speak(text, voice_id)

    def listen_start(self, timeout_s=30.):
        return self.voice.listen_start(timeout_s)

    def listen_stop(self):
        return self.voice.listen_stop()

    def close(self):
        self.voice.close()
        super().close()
