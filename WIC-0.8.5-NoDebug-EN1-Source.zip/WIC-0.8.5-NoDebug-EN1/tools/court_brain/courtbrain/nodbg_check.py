"""Exercise the real mailbox and event renderer without starting any AI client."""
from __future__ import annotations
import json
from pathlib import Path
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from . import bundle, config
from .history import HistoryTail
from .mailbox import Mailbox
from .protocol import parse_lines

LONG_TEXT = ('Test: «The Royal Council». "The envoy has arrived," said the chancellor; a decision was made.\nNumbers: 12.5; 1337.4.1. Line break preserved.\n\n'
             + '\n'.join(f'Paragraph {n}: a long account of the council, the embassy and affairs of the realm. End of paragraph.' for n in range(1, 65))
             + '\n\nEND OF LONG TEXT: everything arrived.')
SHORT_TEXT = 'Short reply: "Done".\nSecond line.\nEND — no tail from the previous text should remain.'


def test_law():
    """Synthetic law for a disposable campaign; never a live AI request."""
    from . import actions, laws
    actions.set_text_language('english')
    law, why = laws.validate(dict(action='create', name='Test: «Grain Charter»',
        about='Text in the laws window. Punctuation: comma, period; quotation marks «in place».',
        options=[dict(name='Keep the custom', desc='No new obligations.', gains=[], costs=[], values=[]),
                 dict(name='Open the grain stores', desc="Supply grain to the villages: relief for the people at the crown's expense.",
                      gains=[dict(area='peasants_favour', strength=1)],
                      costs=[dict(area='taxation', strength=1)], values=[])]), {})
    if law is None:
        raise ValueError(why)
    return law


class Check:
    def __init__(self, root):
        self.root = root
        root.title('WIC NoDebug — events without AI')
        root.geometry('850x750')
        self.cfg = config.load()
        self.mail = Mailbox(run_dir=self.cfg.run_path, dynamic_loc=self.cfg.dynamic_loc_path,
                            language_key='l_' + self.cfg.game_language)
        self.mail.on_note = self.note
        self.mail.on_dropped = lambda label: self.note('Event cancelled: text was not acknowledged. ' + label)
        self.tail = HistoryTail(self.cfg.user_path / 'console_history.txt')
        self.tail.skip_to_end()
        self.observations = []
        self.sent = []
        self.ready = False
        self.installed = False
        frame = ttk.Frame(root, padding=15)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='Test the complete event delivery path', font=('Segoe UI', 15)).pack(anchor='w')
        ttk.Label(frame, wraplength=800, text='No AI service or account is used here. Close Court Brain and EU5, install this build, then start a new disposable campaign with only WIC NoDebug 0.8.5 EN enabled. Remove -debug_mode and -console from launch options.').pack(fill='x', pady=12)
        ttk.Button(frame, text='1. Install 0.8.5 NoDebug EN1', command=self.install).pack(anchor='w', pady=6)
        ttk.Button(frame, text='2. Send long text', command=lambda: self.send(1)).pack(anchor='w', pady=6)
        ttk.Button(frame, text='3. Replace with short text', command=lambda: self.send(2)).pack(anchor='w', pady=6)
        ttk.Button(frame, text='4. Show test law (disposable campaign only)', command=lambda: self.send(3)).pack(anchor='w', pady=6)
        self.log = tk.Text(frame, wrap='word', height=13, state='disabled')
        self.log.pack(fill='both', expand=True, pady=8)
        self.long_ok = tk.BooleanVar()
        self.short_ok = tk.BooleanVar()
        self.law_ok = tk.BooleanVar()
        ttk.Checkbutton(frame, text='The long event preserves spaces, punctuation, paragraphs and END OF LONG TEXT', variable=self.long_ok).pack(anchor='w')
        ttk.Checkbutton(frame, text='The short event has no tail from the previous long text', variable=self.short_ok).pack(anchor='w')
        ttk.Checkbutton(frame, text='The laws window shows Grain Charter, both options and their English descriptions', variable=self.law_ok).pack(anchor='w')
        ttk.Button(frame, text='Save report', command=self.report).pack(anchor='w', pady=10)
        self.note('Install this build first. Start the game normally through Steam.')
        root.after(500, self.poll)

    def note(self, text):
        self.log.configure(state='normal')
        self.log.insert('end', str(text) + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def install(self):
        if bundle._running('eu5.exe'):
            messagebox.showinfo('Close the game', 'Close EU5 before installing this build.')
            return
        try:
            self.installed = bundle.install_mod(self.cfg, self.note)
            if self.installed:
                self.mail.reset_files()
                self.tail.skip_to_end()
                self.note('Enable only WIC NoDebug 0.8.5 EN in the launcher. Start a new disposable campaign and click button 2 here.')
        except Exception as exc:
            self.note('Installation incomplete: ' + str(exc))

    def send(self, stage):
        if not self.installed or not self.ready:
            self.note('Install the build and load a new campaign first; a signal from the game is required.')
            return
        if self.mail.pending():
            self.note('The previous message is still being delivered. Wait for its acknowledgement.')
            return
        if stage == 3:
            from . import laws
            try:
                law = test_law()
                self.mail.send(laws.script(law, None), loc=laws.loc(law), label='no-ai-test-law', mark=False)
                self.sent.append({'stage': stage, 'kind': 'law', 'time': time.time()})
                self.note('Test law sent. Open the socio-economic laws window and check the names and descriptions. You do not need to enact the law to check its text.')
            except Exception as exc:
                self.note('Law was not sent: ' + str(exc))
            return
        text = LONG_TEXT if stage == 1 else SHORT_TEXT
        try:
            self.mail.send(['trigger_event_non_silently = { id = wicnd.1 }'],
                           loc={'votc_out_title': f'NoDebug test: stage {stage}.', 'votc_out_body': text},
                           label=f'no-ai-test-{stage}', mark=False)
            self.sent.append({'stage': stage, 'characters': len(text), 'time': time.time()})
            self.note('Sent stage ' + str(stage) + '. An event should open in the game. Close it before the next step.')
        except Exception as exc:
            self.note('Text was not sent: ' + str(exc))

    def poll(self):
        try:
            for rec in parse_lines(self.tail.poll()):
                if rec.kind == 'HEAD':
                    self.ready = True
                if 'mailseq' in rec.fields:
                    self.mail.sync_seq(rec.i('mailseq'))
                if rec.kind == 'ACK' and rec.fields.get('transport') == 'nd85en':
                    entry = {k: rec.fields.get(k) for k in ('mail', 'loc', 'nodebug', 'achievements', 'transport', 'mod')}
                    self.observations.append(entry)
                    self.mail.ack_pair = rec.i('mod') >= 720
                    self.mail.acknowledge(rec.i('mail'), rec.fields.get('loc'))
                    self.note(f"Acknowledgement {rec.i('mail')}: text {rec.fields.get('loc')}; achievements {rec.fields.get('achievements')}; no debug {rec.fields.get('nodebug') == '1'}")
            if self.installed:
                self.mail.pump()
        except Exception as exc:
            self.note('Check failed: ' + str(exc))
        finally:
            self.root.after(500, self.poll)

    def report(self):
        path = filedialog.asksaveasfilename(initialfile='WIC-0.8.5-NoDebug-EN1-report.json', defaultextension='.json')
        if not path:
            return
        errors = []
        p = self.cfg.logs_path / 'error.log'
        if p.exists():
            with p.open('rb') as stream:
                stream.seek(max(0, p.stat().st_size - 524288))
                tail = stream.read().decode('utf-8', errors='replace')
            errors = [s[-700:] for s in tail.splitlines() if any(k in s for k in ('vnd_', 'wicnd', 'votc_', 'GetFlagName', 'SelectLocalization'))][-60:]
        result = {'build': '0.8.5-NoDebug-EN1', 'sent': self.sent, 'acknowledgements': self.observations,
                  'long_text_visually_confirmed': self.long_ok.get(), 'short_text_visually_confirmed': self.short_ok.get(),
                  'law_text_visually_confirmed': self.law_ok.get(),
                  'recent_mod_errors': errors, 'ai_requests': 0, 'actual_steam_unlock_tested': False}
        Path(path).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        self.note('Report saved. Use a disposable campaign until you have reviewed the results.')


def main():
    if not bundle.single_instance():
        return 1
    from .migrate_ru1 import initialize
    initialize()
    root = tk.Tk()
    Check(root)
    root.mainloop()
    return 0
