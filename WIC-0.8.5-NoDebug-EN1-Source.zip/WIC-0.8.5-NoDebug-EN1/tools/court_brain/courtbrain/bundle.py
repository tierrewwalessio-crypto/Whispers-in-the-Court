"""Standalone English NoDebug companion, containing Court Brain and the mod.

Installs an isolated WIC NoDebug 0.8.5 EN mod and keeps separate settings.
Start EU5 normally through Steam without -debug_mode or -console.
The transport still uses GUI console execution, run files and console history.
"""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable

EU5_APP_ID = "3450310"
MARK = ".votc_bundle"


def frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def mod_source() -> Path:
    """The mod this Court Brain carries."""
    if frozen():
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent)) / "mod" / "WhispersInTheCourt"
    return Path(__file__).resolve().parents[3] / "mod" / "WhispersInTheCourt"


def config_path() -> Path:
    if frozen():
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
        return base / "WhispersInTheCourt-NoDebug085-EN" / "config.json"
    return Path(__file__).resolve().parents[1] / "config.json"


def fingerprint(folder: Path) -> str:
    h = hashlib.sha1()
    for path in sorted(p for p in folder.rglob("*") if p.is_file()):
        h.update(path.relative_to(folder).as_posix().encode())
        h.update(path.read_bytes())
    return h.hexdigest()


def signature(cfg) -> str:
    """The carried mod plus the game files the installation copies (they change with EU5 updates)."""
    h = hashlib.sha1(fingerprint(mod_source()).encode())
    h.update(f"language:{cfg.game_language}".encode())
    if cfg.game_dir:
        from .battleview import FILE as BATTLE_FILE
        try:
            st = (Path(cfg.game_dir) / "game" / BATTLE_FILE).stat()
            h.update(f"{BATTLE_FILE}:{st.st_size}:{int(st.st_mtime)}".encode())
        except OSError:
            pass
    if False:  # NoDebug does not patch debug tooltip visibility
        from .hidedebug import FILES
        for rel in FILES:
            f = Path(cfg.game_dir) / "game" / rel
            try:
                st = f.stat()
                h.update(f"{rel}:{st.st_size}:{int(st.st_mtime)}".encode())
            except OSError:
                h.update(rel.encode())
    return h.hexdigest()


# Windows Security's own pages (a URI it registers): where the player allows an app.
SECURITY_PAGE = "windowsdefender://RansomwareProtection"
BLOCKED_HELP = (
    "Windows is blocking Whispers in the Court from writing in your Documents folder - usually Windows "
    "Security's \"Controlled folder access\" (ransomware protection), sometimes an antivirus or OneDrive. "
    "To allow it: Windows Security > Virus & threat protection > Ransomware protection > Allow an app through "
    "Controlled folder access > add WhispersInTheCourt.exe. If your antivirus quarantined it, restore it and add "
    "its folder to the exclusions. Then close EU5 and reopen Whispers in the Court. (The page opens now.)")


def _install_failed(exc: OSError, target: Path, log: Callable[[str], None]) -> None:
    """Why the mod could not be written, in words a player can act on."""
    code = getattr(exc, "winerror", None)
    if isinstance(exc, PermissionError) or code == 5:
        log(f"WARNING: the mod could not be installed in {target.parent}: access denied. " + BLOCKED_HELP)
        if os.name == "nt":
            try:
                os.startfile(SECURITY_PAGE)            # noqa: S606 - Windows Security's own page
            except OSError:
                pass
    elif code == 32:
        log(f"WARNING: the mod could not be installed: a file of it is in use ({exc.filename}). Close EU5 (and, if "
            "your Documents are on OneDrive, wait for it to finish syncing), then reopen Whispers in the Court.")
    else:
        log(f"WARNING: the mod could not be installed: {exc}. Close EU5 and reopen Whispers in the Court.")


def install_mod(cfg, log: Callable[[str], None]) -> bool:
    """Copy the carried mod into EU5's mod folder, with what depends on this player's game."""
    source = mod_source()
    if not source.is_dir():
        log(f"WARNING: the mod to install is missing ({source}).")
        return False
    if not cfg.user_dir or not cfg.user_path.is_dir():
        log("WARNING: EU5's folder in Documents was not found. Start the game once, then reopen "
            "Whispers in the Court. If it still is not found, set \"user_dir\" in "
            f"{config_path()} to the folder that holds EU5's logs, mod and save games.")
        return False
    target = cfg.user_path / "mod" / "WhispersInTheCourtNoDebug085EN"
    # Keep the player's previous local installation recoverable. Workshop files are untouched.
    if target.exists():
        backup = config_path().parent / "backups" / ("WhispersInTheCourt-" + time.strftime("%Y%m%d-%H%M%S"))
        try:
            shutil.copytree(target, backup)
            log(f'Previous mod backed up to: {backup}')
        except OSError as exc:
            log(f'Could not back up the previous mod; installation cancelled: {exc}')
            return False
    # The new copy is made beside the old one and swapped in only when it is whole: a copy Windows
    # stops half-way never leaves the player with half a mod.
    fresh = target.with_name(target.name + ".new")
    stale = target.with_name(target.name + ".old")
    try:
        for leftover in (fresh, stale):
            if leftover.exists():
                shutil.rmtree(leftover)
        shutil.copytree(source, fresh)
        if target.exists():
            target.rename(stale)
        fresh.rename(target)
        if stale.exists():
            shutil.rmtree(stale, ignore_errors=True)
    except OSError as exc:
        if not target.exists() and stale.exists():
            try:
                stale.rename(target)             # put the old mod back
            except OSError:
                pass
        shutil.rmtree(fresh, ignore_errors=True)
        _install_failed(exc, target, log)
        return False
    _mark_name(target)
    languages = _localize(target, cfg)
    if cfg.game_language != "english":
        log(f"EU5 runs in {cfg.game_language}: the mod's texts are installed for it too.")
    from .names import NameRegistry, PlaceNames
    NameRegistry(cfg.state_dir).write_loc(target)      # names chosen in earlier games
    PlaceNames(cfg.state_dir).write_loc(target)        # places renamed in earlier games
    if cfg.game_dir:
        from .battleview import install as battle_button
        if not battle_button(Path(cfg.game_dir), target):
            log("The battle window of this game version was not recognised: take command of a battle from the "
                "army's own \"Command the Battle\" ability.")
    if False:  # NoDebug does not patch debug tooltip visibility
        from .hidedebug import install as hide_debug
        done = hide_debug(Path(cfg.game_dir), target)
        if done:
            log(f"Purple debug boxes hidden ({sum(n for _, n in done)} conditions in {len(done)} interface "
                "files, taken from your version of the game).")
    try:
        (target / MARK).write_text(signature(cfg), encoding="utf-8")
    except OSError:
        pass
    log(f"Mod installed in {target}. In the EU5 launcher, enable \"{INSTALLED_NAME}\" "
        "(not the Workshop copy, if you have one).")
    return True


# The copy this program installs is the complete one: its name says so in the
# launcher, beside a Workshop subscription that lacks the per-game parts.
INSTALLED_NAME = "WIC NoDebug 0.8.5 EN"


def _localize(target: Path, cfg) -> list[str]:
    """The mod ships its texts in English. The game only reads the files of the
    language it runs in, so the English files are copied for every language EU5
    has (the interface stays in English), and the bridge's reload command names
    the language actually in use - a reload of the wrong language never brings
    the scene's words in."""
    from .config import GAME_LANGUAGES
    root = target / "main_menu" / "localization"
    english = root / "english"
    command = cfg.reload_command
    done = []
    for lang in GAME_LANGUAGES:
        folder = root / lang
        folder.mkdir(parents=True, exist_ok=True)
        for src in english.glob("*_l_english.yml"):
            # Read authored translations from the bundle, never from a file about to be overwritten.
            translated = mod_source() / "main_menu" / "localization" / lang / src.name.replace("_l_english.yml", f"_l_{lang}.yml")
            text = (translated if translated.is_file() else src).read_text(encoding="utf-8-sig")
            if lang != "english":
                text = text.replace("l_english:", f"l_{lang}:", 1)
            text = text.replace("reload switchlanguage english", command)
            (folder / src.name.replace("_l_english.yml", f"_l_{lang}.yml")).write_bytes(
                b"\xef\xbb\xbf" + text.encode("utf-8"))
        done.append(lang)
    return done


def _mark_name(target: Path) -> None:
    meta = target / ".metadata" / "metadata.json"
    try:
        text = meta.read_text(encoding="utf-8-sig")
        text = re.sub(r'("name"\s*:\s*)"[^"]*"', lambda m: m.group(1) + '"' + INSTALLED_NAME + '"', text, count=1)
        meta.write_text(text, encoding="utf-8")
    except OSError:
        pass


# Where earlier versions of the mod installed themselves, under other names.
OLD_FOLDERS = ("VoicesOfTheCourt",)
MOD_ID = "votc_eu5_court_voices"


def _remove_old_copies(cfg, log: Callable[[str], None]) -> None:
    """An earlier copy of this mod under its old name would show up twice in the launcher."""
    for name in OLD_FOLDERS:
        old = cfg.user_path / "mod" / name
        meta = old / ".metadata" / "metadata.json"
        try:
            if meta.is_file() and MOD_ID in meta.read_text(encoding="utf-8-sig", errors="replace"):
                shutil.rmtree(old)
                log(f"Removed the old copy of the mod ({old.name}): it is now \"Whispers in the Court\".")
        except OSError:
            pass


def ensure_mod(cfg, log: Callable[[str], None]) -> None:
    """Install the mod if it is missing, update it if it is not the one carried here."""
    source = mod_source()
    if not source.is_dir() or not cfg.user_dir:
        if not cfg.user_dir:
            log("WARNING: EU5's folder in Documents was not found. Start the game once, then reopen "
                "Whispers in the Court. If it still is not found, set \"user_dir\" in "
                f"{config_path()} to the folder that holds EU5's logs, mod and save games.")
        return
    target = cfg.user_path / "mod" / "WhispersInTheCourtNoDebug085EN"
    try:
        installed = (target / MARK).read_text(encoding="utf-8").strip()
    except OSError:
        installed = ""
    if installed and installed == signature(cfg):
        log('The installed mod is up to date.')
        return
    if target.exists() and _running("eu5.exe"):
        # Replacing the mod under a running game leaves it with the old scripts in memory, its file
        # watcher broken, and Court Brain sending orders only the new mod knows: it crashes. The
        # update waits until the game is closed (Start EU5 does it first).
        log('EU5 has an older mod loaded. To update, close the game and reopen Court Brain or click Install mod. Replacing files while the game is running may cause a crash.')
        return
    log('Updating the mod in the EU5 folder…' if target.exists() else 'Installing the mod in the EU5 folder…')
    install_mod(cfg, log)


def steam_app_id(game_dir: str) -> str:
    """EU5's Steam id, from the library manifest beside the game when it can be read."""
    if game_dir:
        steamapps = Path(game_dir).parents[1]
        folder = Path(game_dir).name
        for manifest in steamapps.glob("appmanifest_*.acf"):
            try:
                text = manifest.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if re.search(r'"installdir"\s+"' + re.escape(folder) + '"', text):
                m = re.search(r'"appid"\s+"(\d+)"', text)
                if m:
                    return m.group(1)
    return EU5_APP_ID


DEBUG_HELP = 'This build runs without -debug_mode. Remove that argument from Steam launch options.'

# What the player is told after "Install mod": the game is started by the player, never by this program.
HOW_TO_PLAY = (
    'Mod installed.\n\n1. Start EU5 normally through Steam, without -debug_mode or -console.\n\n2. In the launcher, enable only ' + INSTALLED_NAME + ' from the Whispers in the Court editions.\n\n3. Leave Court Brain open while playing.\n\nAfter a Court Brain update, close the game and click Install mod again.')



def install_now(cfg, log: Callable[[str], None]) -> tuple[bool, str]:
    """The "Install mod" button: the real mod into EU5's folder, then how to start the game."""
    if _running("eu5.exe"):
        return False, ('Close EU5 before installing the mod.')
    if not install_mod(cfg, log):
        return False, 'Could not install the mod. See the Court Brain log for the cause.'
    return True, HOW_TO_PLAY


def _running(image: str) -> bool:
    """Is a program with this file name running? (Windows only; False elsewhere.)"""
    # Read as bytes: tasklist writes in the console's own code page, which on a
    # Windows in another language is not UTF-8 (the output then came back as None
    # and "Start EU5" failed). The image name itself is always plain ASCII.
    try:
        out = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {image}", "/NH"], capture_output=True,
                             timeout=10, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, ValueError, subprocess.SubprocessError):
        return False
    return image.lower().encode("ascii") in (out.stdout or b"").lower()


def launch_game(cfg, log: Callable[[str], None]) -> None:
    """Use the normal Steam launch path, without developer options."""
    if _running('eu5.exe'):
        log('EU5 is already running.')
        return
    ensure_mod(cfg, log)
    try:
        os.startfile(f'steam://rungameid/{steam_app_id(cfg.game_dir)}')
        log('Starting EU5 normally through Steam. Enable only WIC NoDebug 0.8.5 EN in the launcher.')
    except (AttributeError, OSError) as exc:
        log(f'Start EU5 manually through Steam: {exc}')


_MUTEX = None


def single_instance() -> bool:
    """True if no other Court Brain runs: two would read and write the same files."""
    global _MUTEX
    if not hasattr(sys, "getwindowsversion"):
        return True
    import ctypes
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _MUTEX = kernel32.CreateMutexW(None, False, "Local\\WhispersInTheCourt.CourtBrain")
    return ctypes.get_last_error() != 183                     # ERROR_ALREADY_EXISTS
