"""Russian wording for the new laws; does not alter gameplay scripts."""
from .russian_text import POLICIES, SOCIETY

STRENGTH = {1: 'небольшое', 2: 'умеренное', 3: 'значительное'}
DRIFT = {1: 'медленное', 2: 'постепенное'}


def effects_text(option):
    parts = [f"{POLICIES[g['area']]}: {STRENGTH[g['strength']]} повышение" for g in option['gains']]
    parts += [f"{POLICIES[c['area']]}: {STRENGTH[c['strength']]} снижение" for c in option['costs']]
    parts += [f"{DRIFT[v['strength']]} смещение ценностей: {SOCIETY[v['value']]}" for v in option['values']]
    return '; '.join(parts) if parts else 'без изменений: сохраняется прежний порядок'


def label(law):
    if law['action'] == 'repeal':
        return f"⚖ Закон отменён: {law['name']}"
    return (f"⚖ Новый закон: {law['name']} (вариантов: {len(law['options'])}). "
            'Выберите вариант в окне законов, в разделе социально-экономических законов')


def loc(law):
    slot = law['slot']
    out = {f'votc_law_{slot}': law['name'],
           f'votc_law_{slot}_desc': (law.get('about') or '') + ' (Составлен по повелению правителя.)'}
    for i, option in enumerate(law['options'], 1):
        effect = 'После полного вступления в силу: ' + effects_text(option) + '.'
        out[f'votc_law_{slot}_p{i}'] = option['name']
        out[f'votc_law_{slot}_p{i}_desc'] = option['desc'] + '\n\n' + effect
        out[f'votc_law_{slot}_p{i}_tt'] = effect
    return out
