"""Account UI. Network work stays off Tk's thread; no game or inference on sign-in."""
import queue
import threading
import tkinter as tk
from tkinter import ttk
from types import SimpleNamespace
import webbrowser

from .chatgpt_auth import AccountStore, sign_in
from .chatgpt import ChatGPTClient
from .player2 import Player2Client
from .drawer import NAVY, TEXT, TEXT_DIM, GOLD, Plate


class ChatGPTPanel(tk.Frame):
    def __init__(self, parent, art, choices):
        super().__init__(parent, bg=NAVY)
        self.art, self.choices = art, choices
        self.store = AccountStore()
        self.results = queue.Queue()
        self.cancel = threading.Event()
        self.busy = False
        self.catalog = []
        self.accounts = []
        self.bind("<Destroy>", lambda e: self.cancel.set() if e.widget is self else None)
        tk.Label(self, text='ChatGPT plan · shared allowance with Codex and other apps',
                 bg=NAVY, fg=GOLD, font=art.note, wraplength=700, justify="left").pack(fill="x")
        tk.Label(self, text='Sign in through your browser; do not enter your password in the mod. Access depends on your account.\nVoice and dictation still require Player2.',
                 bg=NAVY, fg=TEXT_DIM, font=art.small, wraplength=700, justify="left").pack(fill="x", pady=4)
        self.account = ttk.Combobox(self, state="readonly")
        self.account.pack(fill="x", pady=3)
        self.account.bind("<<ComboboxSelected>>", self._select_account)
        row = tk.Frame(self, bg=NAVY)
        row.pack(fill="x", pady=4)
        Plate(row, "Continue with ChatGPT", lambda: self._login(False), font=art.btn).pack(side="left")
        Plate(row, 'Another account', lambda: self._login(True), font=art.btn).pack(side="left", padx=6)
        Plate(row, 'Sign out', self._logout, font=art.btn).pack(side="left")
        self.model = ttk.Combobox(self, state="readonly")
        self.model.pack(fill="x", pady=3)
        self.model.bind("<<ComboboxSelected>>", self._select_model)
        row = tk.Frame(self, bg=NAVY)
        row.pack(fill="x", pady=4)
        Plate(row, 'Refresh models', self._models, font=art.btn).pack(side="left")
        Plate(row, 'Test response', self._test, font=art.btn).pack(side="left", padx=6)
        Plate(row, 'ChatGPT limits', lambda: webbrowser.open("https://chatgpt.com/#settings/Usage"),
              font=art.btn).pack(side="left")
        self.note = tk.Label(self, text='Testing a response uses a small amount of your allowance. There are no game consequences.',
                             bg=NAVY, fg=TEXT, font=art.small, wraplength=700, justify="left", anchor="w")
        self.note.pack(fill="x", pady=4)
        self._refresh_accounts()
        self.after(100, self._poll)

    def _refresh_accounts(self):
        try:
            self.accounts = self.store.accounts()
        except Exception as exc:
            self.note.configure(text=str(exc))
            return
        self.account.configure(values=[a["label"] + ("" if a["connected"] else ' · signed in') for a in self.accounts])
        selected = self.choices.get("chatgpt_account", "")
        for i, account in enumerate(self.accounts):
            if account["id"] == selected:
                self.account.current(i)
                break
        else:
            self.account.set('Choose an account or sign in')
        self.model.set(self.choices.get("chatgpt_model", "") or 'Refresh the model list first')

    def _select_account(self, _event=None):
        if self.busy:
            self._refresh_accounts()
            return
        i = self.account.current()
        if i >= 0:
            self.choices["chatgpt_account"] = self.accounts[i]["id"]
            self.choices["chatgpt_model"] = ""
            self.catalog = []
            self.model.configure(values=[])
            self.model.set("")
            self._models()

    def _select_model(self, _event=None):
        i = self.model.current()
        if i >= 0:
            self.choices["chatgpt_model"] = self.catalog[i]["slug"]

    def _run(self, kind, fn, message):
        if self.busy:
            return
        self.busy = True
        self.note.configure(text=message)
        def worker():
            try:
                self.results.put((kind, fn(), None))
            except Exception as exc:
                # Known auth/transport errors contain no tokens or response bodies.
                from .chatgpt_auth import AuthError
                from .player2 import Player2Error
                text = str(exc) if isinstance(exc, (AuthError, Player2Error)) else 'ChatGPT connection error. Sign in again.'
                self.results.put((kind, None, text))
        threading.Thread(target=worker, daemon=True).start()

    def _login(self, new):
        key = "" if new else self.choices.get("chatgpt_account", "")
        self._run("login", lambda: sign_in(self.store, key, cancel=self.cancel),
                  'Complete sign-in and grant plan access in your browser. Waiting for up to 5 minutes.')

    def _client(self):
        return ChatGPTClient(SimpleNamespace(chatgpt_account=self.choices.get("chatgpt_account", ""),
                                            chatgpt_model=self.choices.get("chatgpt_model", ""),
                                            request_timeout_s=120, max_tokens=3000),
                             Player2Client("http://127.0.0.1:4315/v1", "voices-of-the-court-eu5"), store=self.store)

    def _models(self):
        client = self._client()
        self._run("models", client.model_catalog, 'Fetching available ChatGPT models…')

    def _test(self):
        client = self._client()
        schema = {"type": "object", "properties": {"answer": {"type": "string", "enum": ['Done']}},
                  "required": ["answer"], "additionalProperties": False}
        self._run("test", lambda: client.complete_json([{"role": "user", "content": 'Reply: Done'}], schema,
                                                       schema_name="connection_test"), "Testing the selected model's response…")

    def _logout(self):
        key = self.choices.get("chatgpt_account", "")
        if key:
            self._run("logout", lambda: self.store.sign_out(key), 'Signing out of ChatGPT…')

    def _poll(self):
        try:
            kind, value, error = self.results.get_nowait()
        except queue.Empty:
            self.after(100, self._poll)
            return
        self.busy = False
        if error:
            if kind == "login":
                self._refresh_accounts()
            self.note.configure(text=error)
        elif kind == "login":
            self.choices["chatgpt_account"] = value
            self.choices["chatgpt_model"] = ""
            self._refresh_accounts()
            self._models()
        elif kind == "models":
            self.catalog = value
            self.model.configure(values=[m["display_name"] for m in value])
            slug = self.choices.get("chatgpt_model", "")
            index = next((i for i, m in enumerate(value) if m["slug"] == slug), None)
            if index is not None:
                self.model.current(index)
            else:
                self.choices["chatgpt_model"] = ""
                self.model.set('Select a model')
            self.note.configure(text='Account connected. Select a model and click Test response.')
        elif kind == "logout":
            self._refresh_accounts()
            self.note.configure(text='You have signed out of ChatGPT.' if value else
                                'Local sign-in was removed; access revocation was not confirmed. Disconnect the app in ChatGPT settings.')
        elif kind == "test":
            self.note.configure(text='Response received and validated. You can save the settings.')
        self.after(100, self._poll)
