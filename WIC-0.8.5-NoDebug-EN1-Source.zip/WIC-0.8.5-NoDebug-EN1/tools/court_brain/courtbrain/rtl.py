"""Right-to-left text (Arabic, Persian, Hebrew...) for the game's own text.

EU5 lays every line out from left to right and knows nothing of right-to-left scripts: each
word comes out whole, but the words of an Arabic sentence come out in the reverse order
(a tester saw "العربية اللغة أريد أنا" for "أنا أريد اللغة العربية"). So the text the game
shows is written here in VISUAL order: cut into lines short enough that the game never wraps
them itself, and in each line the words reversed - runs of Latin names and numbers kept in
their own order, punctuation moved to the side it belongs on.

Only text that is mostly written in a right-to-left script is touched: every other language
reaches the game exactly as before.
"""

from __future__ import annotations

import re

_RTL = re.compile(r"[֐-ࣿיִ-﷿ﹰ-﻿]")
_LTR = re.compile(r"[A-Za-z0-9À-ɏ]")
_MIRROR = str.maketrans("()[]{}<>«»‹›", ")(][}{><»«›‹")
_EDGES = re.compile(r"^(\W*)(.*?)(\W*)$", re.S)

# Characters per line: short enough that an event's text box never wraps a line itself
# (a wrap the game makes would put the end of the sentence on the line above).
WIDTH = 44


def is_rtl(text: str) -> bool:
    """Is this text mostly written in a right-to-left script?"""
    letters = [c for c in text or "" if c.isalpha()]
    return bool(letters) and sum(1 for c in letters if _RTL.match(c)) > len(letters) / 2


def _flip(token: str) -> str:
    """A right-to-left word in visual order: the punctuation that ends it goes before it."""
    m = _EDGES.match(token)
    if not m:
        return token
    lead, core, trail = m.groups()
    return trail[::-1].translate(_MIRROR) + core + lead[::-1].translate(_MIRROR)


def _visual_line(line: str) -> str:
    groups: list[tuple[bool, list[str]]] = []
    for tok in line.split(" "):
        ltr = bool(tok) and not _RTL.search(tok) and bool(_LTR.search(tok))
        if ltr and groups and groups[-1][0]:
            groups[-1][1].append(tok)
        else:
            groups.append((ltr, [tok]))
    out: list[str] = []
    for ltr, toks in reversed(groups):
        if ltr:
            out.append(" ".join(toks))           # a name or a number reads as it is written
        else:
            out += [_flip(t) for t in reversed(toks)]
    return " ".join(out)


def _wrap(line: str, width: int) -> list[str]:
    rows, row = [], ""
    for word in line.split(" "):
        if row and len(row) + 1 + len(word) > width:
            rows.append(row)
            row = word
        else:
            row = f"{row} {word}" if row else word
    rows.append(row)
    return rows


def visual(text: str, width: int = WIDTH) -> str:
    """The text as the game must be given it to show it right; unchanged unless it is right-to-left."""
    if not is_rtl(text):
        return text
    out: list[str] = []
    for line in text.split("\n"):
        if not line.strip() or not is_rtl(line):
            out.append(line)
            continue
        out += [_visual_line(row) for row in _wrap(line.strip(), width)]
    return "\n".join(out)
