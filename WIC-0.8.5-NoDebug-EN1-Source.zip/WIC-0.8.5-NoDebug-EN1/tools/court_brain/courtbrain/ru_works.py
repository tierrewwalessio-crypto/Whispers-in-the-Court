"""Russian labels for works; generated game commands stay in works.py."""
import re


def funding(w):
    payer, land = w.get('payer_name', ''), w.get('land_name', '')
    if payer and w.get('paid_by') == 'shared':
        return f'; расходы делятся с державой {payer}'
    if payer:
        return f'; платит {payer}' + (' и сохраняет право собственности' if w.get('owner_ref') == w.get('payer_ref') else '')
    if land:
        return f'; земли державы {land}, расходы несёт корона' + ('; собственность короны' if w.get('owner_ref') == 'root' else '')
    return ''


def label(w, catalog):
    from . import works as W
    k = w['kind']
    if k == 'men':
        n = f"{w.get('people', 0):,}".replace(',', ' ')
        return (f"Пополнение ополчения: {n} солдат от державы {w['from_name']}" if w.get('from_name')
                else f"Передача {n} солдат" + (f" державе {w['to_name']}" if w.get('to_name') else ''))
    if k == 'pay':
        if w.get('from_name'):
            return f"Поступление в казну: {w['amount']} золота от державы {w['from_name']}"
        recipient = w.get('to') or w.get('where_name') or ''
        return f"Выплата из казны: {w['amount']} золота" + (f'; получатель: {recipient}' if recipient else '')
    if k == 'rename':
        pairs = [f"{r['old']} → {r['new']}" for r in w['renames']]
        return 'Новые названия: ' + '; '.join(pairs[:4]) + (f'; ещё: {len(pairs)-4}' if len(pairs)>4 else '')
    if k in W.PERSON_KINDS:
        if k in ('skill_up', 'skill_down'):
            skill = {'adm': 'управление', 'dip': 'дипломатия', 'mil': 'военное дело',
                     'administrative': 'управление', 'diplomatic': 'дипломатия', 'military': 'военное дело'}.get(w['what'][0], 'способности')
            return f"{w.get('who', '')}: {skill} {'+' if k=='skill_up' else '−'}{W.SKILL_POINTS[w['size']]}"
        trait = catalog.traits.get(w['what'][0], {}).get('name', w['what'][0])
        return f"{w.get('who', '')}: {'получает' if k=='trait_add' else 'теряет'} черту «{trait}»"
    what = W._names(w, catalog)
    where = 'по всей державе' if w.get('realm') else f"в области {w.get('where_name', '')}" if w.get('places') else ''
    size = {1: '', 2: ' (значительные усилия)', 3: ' (крупный проект)'}[w['size']]
    texts = {
        'build': f'Строительство: {what} {where}', 'demolish': f'Снос: {what} {where}',
        'upgrade': f'Расширение: {what} {where}', 'downgrade': f'Сокращение: {what} {where}',
        'road': f"Дорога: {w.get('where_name', '')} — {w.get('to_name', '')}",
        'charter': f"Городская грамота для области {w.get('where_name', '')}: {what}",
        'convert_religion': f'Начало обращения населения {where} в веру: {what or "государственная религия"}',
        'convert_culture': f'Начало культурной ассимиляции населения {where}: {what or "государственная культура"}',
        'accept_culture': f'Признание культуры: {what}', 'tolerate_culture': f'Терпимость к культуре: {what}',
        'state_religion': f'Новая государственная религия: {what}',
        'grant_privilege': f'Предоставление привилегии: {what}', 'revoke_privilege': f'Отмена привилегии: {what}',
        'enact_policy': f'Принятие политики: {what}', 'repeal_policy': f'Отмена политики: {what}',
        'adopt_reform': f'Принятие реформы: {what}', 'drop_reform': f'Отмена реформы: {what}',
        'move_capital': f"Перенос столицы: {w.get('where_name', '')}",
        'develop': f"Вложения в развитие области {w.get('where_name', '')}{size}",
        'integrate': f"Интеграция области {w.get('where_name', '')}{size}",
        'control': f"Усиление контроля в области {w.get('where_name', '')}{size}",
        'prosperity': f"Вложения в процветание области {w.get('where_name', '')}{size}",
        'depopulate': f"Гибель или изгнание населения {where}: {what or 'жители'} (около {int(W.POP_SHARE['depopulate'][w['size']]*100)} из 100)",
        'repopulate': f"Заселение {where}: {what or 'жители'}",
        'migrate': f"Переселение: {w.get('moved', w.get('people') or 0):,.0f} человек; {w.get('where_name', '')} → {w.get('to_name', '')}",
    }
    return re.sub(r'\s+', ' ', texts[k]).strip() + funding(w)


def price_text(w):
    from . import works as W
    payer = w.get('payer_name') or w.get('from_name')
    if payer and w.get('paid_by') != 'shared':
        return f'без расходов казны; платит {payer}' if w['kind'] != 'men' else f'без потерь ополчения; солдат присылает {payer}'
    if w['kind'] == 'pay': return f"{w['amount']} золота"
    if w['kind'] == 'men': return f"{w.get('people', 0):,} солдат ополчения".replace(',', ' ')
    price = W._price(w)
    ours = sum(int(m[1]) for line in price if (m := re.fullmatch(r'add_gold = -(\d+)', line)))
    parts = [f'{ours} золота'] if ours else []
    words = {'add_stability': 'стабильность', 'nobles_estate': 'довольство аристократов', 'peasants_estate': 'довольство крестьян'}
    if not ours and any('votc_act_gold_loss' in line for line in price): parts.append('расходы казны')
    for key, word in words.items():
        if any(key in line and '_bonus' not in line for line in price): parts.append(word)
    if w['kind'] == 'build': parts.insert(0, 'стоимость и сроки строительства по правилам игры')
    if payer: parts.append(f'часть расходов несёт {payer}')
    return ', '.join(parts) or 'без значительных дополнительных затрат'
