"""Read-only EU5 binary conversion using pinned MIT-licensed librakaly 0.12.8.

The source save is never overwritten. A single cached text copy is shared by
the metadata and world readers. Its key includes source path, size and mtime.
"""
from __future__ import annotations
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import threading

_lock = threading.RLock()
_library = None


def library():
    global _library
    if _library is not None:
        return _library
    dll = Path(__file__).parent / 'vendor' / 'rakaly.dll'
    lib = c.CDLL(str(dll.resolve()))
    definitions = {
        'eu5_file': ([c.c_void_p, c.c_size_t], c.c_void_p),
        'file_error': ([c.c_void_p], c.c_void_p), 'file_value': ([c.c_void_p], c.c_void_p),
        'file_melt': ([c.c_void_p], c.c_void_p), 'melt_error': ([c.c_void_p], c.c_void_p),
        'melt_value': ([c.c_void_p], c.c_void_p), 'melt_data_length': ([c.c_void_p], c.c_size_t),
        'melt_binary_unknown_tokens': ([c.c_void_p], c.c_bool),
        'melt_write_data': ([c.c_void_p, c.c_void_p, c.c_size_t], c.c_size_t),
        'error_length': ([c.c_void_p], c.c_int),
        'error_write_data': ([c.c_void_p, c.c_void_p, c.c_int], c.c_int),
        'free_error': ([c.c_void_p], None), 'free_melt': ([c.c_void_p], None),
        'free_file': ([c.c_void_p], None),
    }
    for name, (args, result) in definitions.items():
        f = getattr(lib, 'rakaly_' + name)
        f.argtypes, f.restype = args, result
    _library = lib
    return lib


def _checked(lib, pointer, kind):
    if not pointer:
        raise OSError('librakaly returned an empty result')
    error = getattr(lib, f'rakaly_{kind}_error')(pointer)
    if error:
        try:
            n = lib.rakaly_error_length(error)
            if not 0 <= n <= 65536:
                raise OSError('Invalid save conversion error')
            buf = c.create_string_buffer(n)
            lib.rakaly_error_write_data(error, buf, n)
            raise OSError('EU5 save conversion: ' + buf.raw.decode('utf-8', errors='replace'))
        finally:
            lib.rakaly_free_error(error)
    value = getattr(lib, f'rakaly_{kind}_value')(pointer)
    if not value:
        raise OSError('librakaly returned an empty value')
    return value


def _convert(source: Path, target: Path) -> None:
    from .worldsave import free_memory_mb
    free = free_memory_mb()
    if free is not None and free < 1800:
        raise OSError('Not enough free memory to read a binary save (1800 MB required).')
    lib = library()
    data = source.read_bytes()  # Must stay alive until rakaly_free_file.
    file = _checked(lib, lib.rakaly_eu5_file(data, len(data)), 'file')
    try:
        melt = _checked(lib, lib.rakaly_file_melt(file), 'melt')
        try:
            if lib.rakaly_melt_binary_unknown_tokens(melt):
                raise OSError('The save contains unknown fields; the incomplete world snapshot was rejected.')
            length = lib.rakaly_melt_data_length(melt)
            if not 0 < length < 2 * 1024**3:
                raise OSError('Unsupported size of converted save.')
            buffer = c.create_string_buffer(length)
            if lib.rakaly_melt_write_data(melt, buffer, length) != length:
                raise OSError('Could not read the complete save.')
            with target.open('wb') as stream:
                stream.write(buffer)
        finally:
            lib.rakaly_free_melt(melt)
    finally:
        lib.rakaly_free_file(file)


def readable(path: Path | str) -> Path:
    source = Path(path)
    with source.open('rb') as stream:
        header = stream.read(256)
    if b'metadata={' in header:
        return source
    if not header.startswith(b'SAV'):
        raise OSError('Unsupported EU5 save format.')
    from .bundle import config_path
    cache = config_path().parent / 'binary_save_cache'
    with _lock:
        stat = source.stat()
        identity = [str(source.resolve()), stat.st_size, stat.st_mtime_ns]
        key = hashlib.sha256(json.dumps(identity).encode()).hexdigest()
        # One file per source, overwritten atomically after the game saves again.
        slot = hashlib.sha256(str(source.resolve()).encode()).hexdigest()[:20]
        cache.mkdir(parents=True, exist_ok=True)
        output, meta = cache / (slot + '.txt'), cache / (slot + '.json')
        try:
            if meta.read_text() == key and output.is_file():
                os.utime(output, None)
                return output
        except OSError:
            pass
        tmp = output.with_suffix('.tmp')
        try:
            _convert(source, tmp)
            after = source.stat()
            if (stat.st_size, stat.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise OSError('The game is still writing this save; reading will be retried later.')
            os.replace(tmp, output)
            meta.write_text(key)
        finally:
            tmp.unlink(missing_ok=True)
        # Bound the cache to the three most recently used snapshots.
        for old in sorted(cache.glob('*.txt'), key=lambda p: p.stat().st_mtime, reverse=True)[3:]:
            old.unlink(missing_ok=True)
            old.with_suffix('.json').unlink(missing_ok=True)
        return output
