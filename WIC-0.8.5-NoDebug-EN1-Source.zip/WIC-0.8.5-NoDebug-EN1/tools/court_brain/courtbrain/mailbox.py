"""Deliver static-localization fragments, then events, using the game's mailbox.
Text variables and a stamp are sent first. A matching acknowledgement releases
the queued event/effects. No localization reload or debug mode is required.
"""

from __future__ import annotations

import collections
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from . import rtl

BOM =b"\xef\xbb\xbf"


@dataclass
class Mail:
    script: list[str]
    loc: dict[str, str] | None = None
    label: str = ""
    save: bool = False
    queued_at: float = field(default_factory=time.time)
    token: Any = None          # what stamp() said this mail carries
    tries: int = 0             # a text mail that was never acknowledged is sent again
    stamps: list = field(default_factory=list)   # the numbers its text was written under
    not_before: float = 0.0    # sent again only after a pause
    needs_text: bool = False   # shows a scene: pointless (and wrong) without its text
    probe_of: Any = None       # a question to the game: "which text have you loaded?" (no reload)
    probes: int = 0            # how many times the game was asked about this text
    sent_first: float = 0.0    # when this text was first sent, to log how long the game took
    seq: int = 0               # the number it was last sent under


class Mailbox:
    #: seconds to wait for an ACK before assuming the mail was lost and
    #: sending the next one anyway
    ACK_TIMEOUT = 25.0          # a mail is read within 12 s even by a resting bridge; its answer 1.5 s later
    TEXT_ACK_TIMEOUT = 12.0
    SLOW_MARGIN = 15.0          # a mail sent while the bridge polls slowly waits up to 12 s more
    _in_flight_slow = True

    def __init__(self, *, run_dir: Path, dynamic_loc: Path, language_key: str = "l_english") -> None:
        self.run_dir = Path(run_dir)
        self.dynamic_loc = Path(dynamic_loc)
        self.language_key = language_key
        self.seq = 0
        self._queue: "collections.deque[Mail]" = collections.deque()
        self._in_flight: Mail | None = None
        self._sent_at = 0.0
        self._lock = threading.Lock()
        self.loc_values: dict[str, str] = {}
        self.name_values = None
        self._names_sent = {}
        # The mod's own fallbacks for every dynamic key: written with the AI's
        # text, so that a key no scene has filled yet is never missing (the game
        # then warns about it and an event would show its raw key).
        self.fallbacks: dict[str, str] = self._read_fallbacks()
        self.delivered = 0
        # Lines put at the top of every mail at the moment it is written
        # (the memory head), and a callback told when that mail was read.
        self.stamp: Callable[[], tuple[list[str], Any]] | None = None
        # Lines that number the scene a text belongs to (see CourtBrain._scene_lines).
        self.scene_lines: Callable[[dict[str, str]], list[str]] | None = None
        self.on_delivered: Callable[[Any], None] | None = None
        self.on_dropped: Callable[[str], None] | None = None
        self.on_note: Callable[[str], None] | None = None
        # None: not yet known whether the game reports the text it loaded; True: it does.
        self.stamp_check: bool | None = True
        # The bridge polls every 3 s while var:votc_poll_fast is up, every 12 s otherwise.
        # Every mail says which: fast while more is to come (the queue, or keep_fast() - the
        # ruler waiting for an answer), slow when it was the last word. Until the game has
        # read a mail that raised it, a mail may wait up to a slow poll: its acknowledgement
        # is waited for that much longer, so nothing is ever sent twice or dropped for it.
        self.keep_fast: Callable[[], bool] | None = None
        self.game_slow = True
        self._fast_sent: dict[int, bool] = {}
        # Flags the game raised and has already acted on (Court Brain heard the signal, the text
        # reload answered): the next mail lowers them. It costs nothing - a poll runs that mail
        # anyway - and nothing hangs any more on the bridge's scripted GUIs, which lower them too.
        self._lower: set[str] = set()
        # mod 720 on: the acknowledgement takes turns between two flags (votc_in_ack, votc_in_ack_b),
        # so it goes up with every mail and never needs lowering
        self.ack_pair = False
        self._slow_noted = 0.0
        # The last mails the game was given, kept on disk: after a crash they show exactly what
        # the game was running (set by Court Brain; None keeps nothing).
        self.journal: Path | None = None
        self._journal: "collections.deque[str]" = collections.deque(maxlen=12)

    # ------------------------------------------------------------------
    def reset_files(self) -> None:
        """An empty poll file, so the bridge's poll never hits a missing file."""
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self._write(self.run_dir / "votc_nd85en_poll.txt", "votc_bridge_watchdog = yes\n")
        self._write(self.run_dir / "votc_nd85en_in.txt", "# Court Brain: mail now travels in votc_nd85en_poll.txt.\n")

    def sync_seq(self, game_seq: int) -> None:
        """The game reports the last mail it read; never go backwards."""
        with self._lock:
            if game_seq > self.seq:
                self.seq = game_seq

    def ran(self, game_seq: int) -> None:
        """A picture of the realm says the game ran mail game_seq: if that is the mail in flight (one
        without text) and its acknowledgement never came - the console refused it - it is done."""
        with self._lock:
            mail = self._in_flight
            if mail is None or mail.loc or mail.probe_of is not None or mail.seq != game_seq:
                return
        self.acknowledge(game_seq)

    def send(self, script: list[str], *, loc: dict[str, str] | None = None, label: str = "",
             save: bool = False, mark: bool = True) -> None:
        """Queue a mail. save=True also has the game write save games/votc_nd85en_world.eu5."""
        from .nodbg_text import encode
        names = self.name_values() if self.name_values is not None else {}
        changed = {k: v for k, v in names.items() if self._names_sent.get(k) != v}
        loc = {**changed, **(loc or {})} or None
        if loc:
            encode(loc)  # Validate every field before queueing any consequences.
        with self._lock:
            if loc and script:
                # Text first, on its own: the global fragments must exist before
                # the event is created. Only an ACK with the expected text stamp
                # releases the event/effects; no localization reload is involved.
                marks = self.scene_lines(loc) if mark and self.scene_lines is not None else []
                self._queue.append(Mail(script=[], loc=dict(loc), label=label + ":text", save=save))
                self._queue.append(Mail(script=marks + list(script), label=label, needs_text=True))
            else:
                self._queue.append(Mail(script=list(script), loc=dict(loc) if loc else None,
                                        label=label, save=save))
        self.pump()

    # A text is waited for this many times (a question every PROBE_EVERY seconds),
    # sent again once halfway; then the scene goes without it, or not at all.
    PROBES = 8
    PROBE_EVERY = 1.5
    # set by Court Brain from the game's acknowledgements: True when EU5 runs with -debug_mode
    debug_mode: bool | None = None
    _NEVER_READ_DEBUG = '. Text was not acknowledged. Enable only WIC NoDebug 0.8.5 EN.'
    _NEVER_READ = _NEVER_READ_DEBUG

    def acknowledge(self, game_seq: int, loaded: str | None = None) -> None:
        """The game ran mail game_seq, and reports the stamp of the text it has loaded.
        A text mail - or a question about it - is done only when the game really has that
        text: a reload of the whole localisation can take seconds on a slower PC, so
        until then the game is asked again, briefly and without reloading, and the scene
        waits instead of showing without its words."""
        done: Mail | None = None
        note = ""
        with self._lock:
            if game_seq in self._fast_sent:
                # the game has read that mail: it now polls as the mail told it
                self.game_slow = not self._fast_sent[game_seq]
            for old in [s for s in self._fast_sent if s <= game_seq]:
                del self._fast_sent[old]
            mail = self._in_flight
            stamp = (loaded or "").strip()
            text_mail = mail.probe_of if (mail is not None and mail.probe_of is not None) else mail
            waiting = mail is not None and game_seq >= self.seq and text_mail is not None and bool(text_mail.loc)
            if waiting:
                # the reload has run: its flags go down with the next mail (an empty one if none follows,
                # or the bridge's watchdog would take a flag left up for a refused reload, and reload again)
                pass  # NoDebug text does not raise localization reload flags.
            if waiting and stamp.isdigit() and int(stamp) in text_mail.stamps:
                self._names_sent.update({k: v for k, v in text_mail.loc.items()
                                         if k.startswith(('votc_cname_', 'votc_lname_'))})
                self.stamp_check = True               # the game reports its text: the check is trusted
                took = time.time() - (text_mail.sent_first or time.time())
                if took > 4:
                    note = f"the game took {took:.0f} s to load the new text"
                done, self._in_flight = mail, None
                self.delivered += 1
            elif waiting:
                self._in_flight = None
                text_mail.probes += 1
                if text_mail.probes == self.PROBES // 2 and text_mail.tries < 1:
                    # halfway and still the old text: perhaps the reload never ran - once more
                    text_mail.tries += 1
                    text_mail.not_before = time.time() + self.PROBE_EVERY
                    self._queue.appendleft(text_mail)
                    note = f"the game still has the old text ({stamp}) after {text_mail.probes} checks: resending the variables once more"
                elif text_mail.probes < self.PROBES:
                    self._queue.appendleft(Mail(script=[], label=text_mail.label + ":check", probe_of=text_mail,
                                                not_before=time.time() + self.PROBE_EVERY))
                else:
                    if self._queue and self._queue[0].needs_text:
                        dropped = self._queue.popleft()
                        if self.on_dropped is not None:
                            self.on_dropped(dropped.label)
                    note = "the game never loaded the new text: the scene is not shown" + (
                        (self._NEVER_READ_DEBUG if self.debug_mode else self._NEVER_READ) if stamp == "0" else "")
            elif mail is not None and game_seq >= self.seq:
                done = self._in_flight
                self._in_flight = None
                self.delivered += 1
                took = time.time() - self._sent_at
                if took > 20 and time.time() - self._slow_noted > 300:
                    self._slow_noted = time.time()
                    note = f"the game took {took:.0f} s to read a mail (it is slow to answer the bridge)"
            if game_seq > self.seq:
                self.seq = game_seq
        with self._lock:
            if self._lower and not self._queue and self._in_flight is None:
                self._queue.append(Mail(script=[], label="lower"))
        if note and self.on_note is not None:
            self.on_note(note)
        if done is not None and self.on_delivered is not None:
            self.on_delivered(done.token)
        self.pump()

    # a mail that calls votc_signal_<x> raises the flag votc_sig_<this>
    _RAISES = {"estate": "council", "biographer": "reply", "book": "reply", "life": "reply", "century": "reply"}

    @classmethod
    def _raised(cls, mail: Mail) -> set[str]:
        """The flags a mail raises when the game runs it: never lowered by that same mail (the flag
        would not go UP, and the bridge would not fire)."""
        out = {"votc_sig_" + cls._RAISES.get(m.group(1), m.group(1))
               for line in mail.script for m in re.finditer(r"\bvotc_signal_(\w+)", line)}
        if mail.loc:
            out |= {"votc_has_mail_loc", "votc_has_mail_loc_b"}
        return out

    def lower(self, *names: str) -> None:
        """Flags the game has acted on: lowered by the next mail (an empty one if none is coming)."""
        with self._lock:
            self._lower.update(n for n in names if n)
            if not self._queue:
                self._queue.append(Mail(script=[], label="lower"))
        self.pump()

    def in_flight_token(self) -> Any:
        with self._lock:
            return self._in_flight.token if self._in_flight is not None else None

    def scene_in_flight(self) -> bool:
        """A scene's words or its event are still on the way to the game."""
        with self._lock:
            mails = list(self._queue) + ([self._in_flight] if self._in_flight else [])
        return any(m.needs_text or m.probe_of is not None or (m.loc and m.label.endswith(":text")) for m in mails)

    def pending(self) -> int:
        with self._lock:
            return len(self._queue) + (1 if self._in_flight else 0)

    @property
    def last_sent(self) -> float:
        """When the last mail was written for the game (0 before any)."""
        return self._sent_at

    # ------------------------------------------------------------------
    def pump(self) -> None:
        with self._lock:
            if self._in_flight is not None:
                # A text whose reload never answered is sent again soon: the next request
                # raises the other flag, so the bridge fires even if the first stuck.
                wait = self.TEXT_ACK_TIMEOUT if self._in_flight.loc else self.ACK_TIMEOUT
                if self._in_flight_slow:
                    wait += self.SLOW_MARGIN          # it may have waited for a slow poll
                if time.time() - self._sent_at < wait:
                    return
                lost, self._in_flight = self._in_flight, None
                lost = lost.probe_of or lost
                if lost.loc and lost.tries < 2:
                    # The game never confirmed it reloaded the text (a console busy at
                    # that moment): send the text again rather than show a scene without it.
                    lost.tries += 1
                    self._queue.appendleft(lost)
                elif lost.loc and self._queue and self._queue[0].needs_text:
                    # Still no text: the scene is not shown at all - never an empty event
                    # whose consequences nobody chose.
                    dropped = self._queue.popleft()
                    if self.on_dropped is not None:
                        self.on_dropped(dropped.label)
            if not self._queue or self._queue[0].not_before > time.time():
                return
            if self._lower and self._raised(self._queue[0]) & self._lower:
                # that mail raises a flag still to be lowered: lowered first, by a mail of its own
                self._queue.appendleft(Mail(script=[], label="lower"))
            mail = self._queue.popleft()
            drops = sorted(self._lower - self._raised(mail))
            self._lower -= set(drops)
            self.seq += 1
            seq = self.seq
            self._in_flight = mail
            mail.seq = seq
            self._sent_at = time.time()
            self._in_flight_slow = self.game_slow
            more = bool(self._queue)
        # Keep the bridge polling fast while more is to come; the last word lets it rest.
        # A text or a question about it always expects an answer back.
        try:
            busy = self.keep_fast() if self.keep_fast is not None else True
        except Exception:  # noqa: BLE001 - never let this stop a mail: poll fast when unsure
            busy = True
        fast = more or busy or bool(mail.loc) or mail.probe_of is not None
        with self._lock:
            self._fast_sent[seq] = fast

        text_lines = []
        if mail.loc:
            self.loc_values.update(mail.loc)
            mail.stamps.append(seq)
            mail.sent_first = mail.sent_first or time.time()
            from .nodbg_text import encode
            values = {k: v for k, v in self.loc_values.items() if k.startswith(('votc_st', 'votc_law_'))}
            values.update(mail.loc)
            text_lines = encode(values)
            text_lines.append(f'set_global_variable = {{ name = vnd_stamp value = {seq} }}')
        head: list[str] = []
        if self.stamp is not None:
            head, mail.token = self.stamp()
        ack = "votc_in_ack_b = yes" if self.ack_pair and seq % 2 == 0 else "votc_in_ack = yes"
        if mail.loc:
            tail = (["votc_request_save = yes"] if mail.save else []) + [ack]
        elif mail.save:
            tail = ["votc_request_save = yes", ack]
        else:
            tail = [ack]
        pace = "votc_poll_fast_on = yes" if fast else "votc_poll_fast_off = yes"
        lowering = [f"remove_variable = {v}{end}" for v in drops for end in ("", "_stuck", "_retry")]
        body = [f"votc_mail_open = {{ seq = {seq} }}", *head, *lowering, *text_lines, *mail.script, pace, *tail]
        text = (f"if = {{\n\tlimit = {{ votc_mail_is_new = {{ seq = {seq} }} }}\n"
                + "".join(f"\t{line}\n" for line in body)
                + "}\nelse = {\n\tvotc_bridge_watchdog = yes\n}\n")
        # One file, one console command: the poll runs it, the seq runs it once.
        self._write(self.run_dir / "votc_nd85en_poll.txt", text)
        self._keep(seq, mail, body)

    def _keep(self, seq: int, mail: "Mail", body: list[str]) -> None:
        """Note the mail in the journal of the last mails (never in the way of the mail itself)."""
        if self.journal is None:
            return
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        self._journal.append(f"=== mail {seq} [{mail.label}] {stamp}\n" + "\n".join(body) + "\n")
        try:
            self.journal.parent.mkdir(parents=True, exist_ok=True)
            self.journal.write_text("".join(self._journal), encoding="utf-8")
        except OSError:
            pass

    # ------------------------------------------------------------------
    def _read_fallbacks(self) -> dict[str, str]:
        from .nodbg_text import manifest
        languages = manifest()['fallbacks']
        return languages.get(self.language_key.removeprefix('l_'), languages['english'])['votc_dynamic']

    def _write_loc(self, stamp: int = 0) -> None:
        raise RuntimeError('Runtime localization writing is disabled in NoDebug')

    @staticmethod
    def _write(path: Path, text: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_bytes(BOM + text.encode("utf-8"))
        tmp.replace(path)


# A file kept this much larger than its text is written afresh, once, rather than padded.
_PAD_LIMIT = 64 * 1024


def write_watched(path: Path, data: bytes) -> bool:
    """Write a file the game watches (its localisation) so that the game is told of ONE change.

    In debug mode EU5's file watcher reloads ALL its localisation - some 20 MB of text, a second
    or more of frozen game - for every change it hears of in a localisation folder, of any
    language. A temporary file renamed over the old one is four changes, and the game reloaded
    twice for every scene; a rewrite that truncates the file is two. Writing over the old bytes
    in one call is one: the text is never made shorter, the rest is padded with a comment line.
    Nothing is written when the text is unchanged. Returns True when the file was written."""
    path = Path(path)
    try:
        old = path.read_bytes()
    except OSError:
        old = None
    if old is None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return True
    padded = data
    short = len(old) - len(data)
    if short > 0 and len(old) <= max(_PAD_LIMIT, 2 * len(data)):
        padded = data + (b"\n#" + b" " * (short - 3) + b"\n" if short >= 3 else b"\n" * short)
    if padded == old:
        return False
    if len(padded) < len(old):
        path.write_bytes(padded)                # far shorter than before: once, a fresh file
        return True
    with open(path, "r+b", buffering=0) as f:
        view = memoryview(padded)
        while view:
            view = view[f.write(view):]
    return True


# "In short" on top of an event: the gist travels inside the body between these marks, so that only
# here - after the prose is made safe - it is set apart with the game's own formatting codes.
GIST_MARK = "\u2063\u2063"                   # invisible separators, never in any prose


def with_gist(gist: object, body: str) -> str:
    """The event's text with its gist on top, for a ruler who will not read it all. The gist
    begins with the words for "In short" in the event's language and a colon (prompts.GIST)."""
    text = " ".join(str(gist or "").split())[:240]
    import re
    if re.search('[А-Яа-яЁё]', text + body):
        from .russian_text import gist_label
        text = gist_label(text)
    return f"{GIST_MARK}{text}{GIST_MARK}{body}" if text and body else body


def escape_loc(value: str) -> str:
    """Make prose safe inside a Paradox localisation value.

    Double quotes would end the value; raw newlines break the one-key-per-
    line format; [ ] would be read as data functions, $ as a nested key and
    # as a formatting code.
    """
    if value.startswith(GIST_MARK) and value.count(GIST_MARK) >= 2:
        _, gist, body = value.split(GIST_MARK, 2)
        label, sep, rest = gist.partition(":")
        if not sep or len(label) > 30:
            label, rest = "", gist
        if rtl.is_rtl(gist):
            # right to left: the label on a line of its own above, so it stays where it belongs
            head = (f"#bold {_escape(label + ':')}#!\\n" if label else "") + f"#italic {_escape(rest.strip())}#!"
        else:
            head = (f"#bold {_escape(label)}:#! " if label else "") + f"#italic {_escape(rest)}#!"
        return f"{head}\\n\\n{_escape(body)}"     # a blank line, as the localisation file writes it
    return _escape(value)


def _escape(value: str) -> str:
    value = rtl.visual(value)                   # Arabic and the like: in the order the game must draw it
    out = value.replace("\\", "/").replace('"', "”")
    out = out.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "\\n")
    out = out.replace("[", "(").replace("]", ")").replace("$", "").replace("#", "n.")
    return out.strip()
