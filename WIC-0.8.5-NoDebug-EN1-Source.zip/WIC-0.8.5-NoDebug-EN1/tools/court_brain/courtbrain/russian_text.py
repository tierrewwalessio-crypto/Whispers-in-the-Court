"""Presentation helpers only: never rewrite script identifiers or consequences."""
import re


def decree_title(title: str) -> str:
    title = title.strip()
    # The model often already supplies «Указ о ...» or «Указ: ...».
    title = re.sub(r'^(?:Указ\s*:\s*)+(?=Указ\b)', '', title, flags=re.I)
    if re.match(r'^Указ\b', title, re.I):
        return title
    return f'Указ: {title}' if title else 'Указ'


def gist_label(text: str) -> str:
    # Only a known heading at the beginning; never translate quoted English
    # or names in the body of the player's story.
    return re.sub(r'^\s*(?:in\s+short|briefly|summary|вкратце|кратко)\s*:\s*',
                  'Вкратце: ', text, flags=re.I)


TIERS = {'slight': 'едва заметное', 'weak': 'небольшое', 'mild': 'умеренное',
         'severe': 'значительное', 'grand': 'огромное'}
ESTATES = {'nobles_estate': 'Аристократы', 'clergy_estate': 'Священники',
           'burghers_estate': 'Горожане', 'peasants_estate': 'Крестьяне',
           'tribes_estate': 'Племена', 'dhimmi_estate': 'Зимми', 'cossacks_estate': 'Казаки'}
CURRENCIES = {'stability': 'Стабильность', 'prestige': 'Престиж', 'legitimacy': 'Легитимность',
              'government_power': 'Власть правительства', 'army_tradition': 'Армейские традиции',
              'devotion': 'Набожность', 'karma': 'Карма', 'horde_unity': 'Единство орды',
              'republican_tradition': 'Республиканские традиции'}
POLICIES = {
    'taxation': 'Налогообложение', 'production': 'Производство', 'trade': 'Торговля',
    'prosperity': 'Процветание', 'currency': 'Чеканка монет', 'army_upkeep': 'Содержание армии',
    'navy_upkeep': 'Содержание флота', 'building_upkeep': 'Содержание зданий',
    'construction': 'Строительство', 'control': 'Контроль над землями', 'manpower': 'Людские ресурсы',
    'food': 'Снабжение продовольствием', 'morale': 'Боевой дух армии', 'discipline': 'Дисциплина',
    'siegecraft': 'Осадное дело', 'army_supply': 'Снабжение армии', 'army_speed': 'Скорость передвижения армии',
    'morale_recovery': 'Восстановление боевого духа', 'conversion': 'Обращение в веру',
    'heretic_conversion': 'Обращение еретиков', 'tolerance_heretics': 'Терпимость к еретикам',
    'tolerance_heathens': 'Терпимость к язычникам', 'state_faith': 'Рвение государственной веры',
    'assimilation': 'Ассимиляция', 'cultural_influence': 'Культурное влияние', 'learning': 'Образование',
    'population_growth': 'Рост населения', 'social_mobility': 'Социальная мобильность',
    'colonization': 'Колонизация', 'exploration': 'Исследование земель', 'diplomacy': 'Дипломатия',
    'espionage': 'Шпионаж', 'subject_loyalty': 'Верность подданных', 'sailors': 'Моряки',
    'naval_morale': 'Боевой дух флота', 'shipbuilding': 'Кораблестроение', 'research': 'Исследования',
    'institutions': 'Институты', 'integration': 'Интеграция', 'separatism': 'Сепаратизм',
    'rebellion': 'Мятежи', 'legitimacy': 'Легитимность', 'prestige': 'Престиж', 'cabinet': 'Кабинет',
    'court_costs': 'Расходы двора', 'crown_power': 'Власть короны',
    'nobles_favour': 'Благосклонность аристократов', 'clergy_favour': 'Благосклонность священников',
    'burghers_favour': 'Благосклонность горожан', 'peasants_favour': 'Благосклонность крестьян',
    'trade_income': 'Доход от торговли', 'recruitment': 'Набор войск', 'fortifications': 'Укрепления',
    'mercenaries': 'Наёмники', 'nobles_taxes': 'Налоги с аристократов', 'clergy_taxes': 'Налоги со священников',
    'burghers_taxes': 'Налоги с горожан', 'peasants_taxes': 'Налоги с крестьян',
    **{f'income{i}': 'Новый постоянный доход короны' for i in range(1, 9)},
}
GOVERNMENTS = {'monarchy': 'монархия', 'republic': 'республика', 'theocracy': 'теократия',
               'tribe': 'племенной строй', 'steppe_horde': 'степная орда'}
RANKS = {'rank_county': 'графство', 'rank_duchy': 'герцогство',
         'rank_kingdom': 'королевство', 'rank_empire': 'империя'}
ORDERS = {'declare_war': 'Объявление войны', 'white_peace': 'Белый мир и перемирие на 5 лет',
          'form_alliance': 'Заключение союза', 'break_alliance': 'Расторжение союза',
          'guarantee': 'Гарантия независимости', 'grant_military_access': 'Предоставление военного доступа',
          'press_claim': 'Получение повода для войны', 'swear_truce': 'Перемирие на 5 лет',
          'take_submission': 'Принятие вассальной присяги'}
REGIONS = {'far': 'в отдалённых от столицы землях', 'outer': 'за пределами столичной области',
           'foreign_culture': 'в землях иной культуры', 'other_faith': 'в землях иной веры',
           'low_control': 'в землях со слабым контролем короны'}
SOCIETY = {
    'absolutism': 'абсолютизм', 'liberalism': 'либерализм',
    'mysticism': 'мистицизм', 'jurisprudence': 'правоведение',
    'centralization': 'централизация', 'decentralization': 'децентрализация',
    'traditionalist': 'традиционализм', 'innovative': 'новаторство',
    'spiritualist': 'духовность', 'humanist': 'гуманизм', 'aristocracy': 'аристократия',
    'plutocracy': 'плутократия', 'serfdom': 'крепостничество', 'free_subjects': 'свободные подданные',
    'mercantilism': 'меркантилизм', 'free_trade': 'свободная торговля',
    'belligerent': 'воинственность', 'conciliatory': 'миролюбие', 'quality': 'качество',
    'quantity': 'количество', 'offensive': 'наступление', 'defensive': 'оборона',
    'land': 'сухопутная ориентация', 'naval': 'морская ориентация',
    'capital_economy': 'капитальная экономика', 'traditional_economy': 'традиционная экономика',
    'individualism': 'индивидуализм', 'communalism': 'общинность',
    'outward': 'открытость миру', 'inward': 'сосредоточенность на внутренних делах',
}
PACT_MOVES = {
    'pays_exact': '{party}: выплата долга в вашу казну — {gold} золота',
    'join_war': '{party}: вступление в вашу войну против {enemy} по собственному решению',
    'declare_war': '{party}: объявление вам войны по собственному решению',
    'break_alliance': '{party}: расторжение союза с вами по собственному решению',
    'goodwill': '{party}: улучшение отношения и рост доверия к вам',
    'alliance': '{party}: заключение союза с вами по собственному решению',
    'make_peace': '{party}: заключение мира и перемирия с вами по собственному решению',
    'casus_belli': 'Вы получаете повод для войны против {party}',
    'pays': '{party}: уплата долга золотом в вашу казну',
    'ruler_join_war': 'Вы вступаете в войну на стороне {party} против {enemy}',
}


def years(value) -> str:
    n = int(value)
    suffix = 'лет' if 11 <= n % 100 <= 14 else ('год' if n % 10 == 1 else 'года' if 2 <= n % 10 <= 4 else 'лет')
    return f'{n} {suffix}'


def action(a, loc):
    k = a['kind']
    tier = TIERS.get(a.get('tier'), '')
    up = a.get('sign') == 'bonus'
    change = f"{tier} {'повышение' if up else 'снижение'}".strip()
    if k in ('gold_gain', 'gold_loss') and a.get('gold'):
        return f"Казна: {'+' if k == 'gold_gain' else '−'}{a['gold']} золота"
    if k == 'gift_gold' and a.get('gold'):
        return f"Подарок другому двору: {a['gold']} золота"
    if k == 'great_effort' and a.get('gold') and a.get('domain') in ('treasury', 'works'):
        return (f"Всеобщие пожертвования: +{a['gold']} золота в казну" if a['domain'] == 'treasury'
                else f"Всеобщие строительные усилия на 2 года; расход казны: {a['gold']} золота")
    if k in CURRENCIES:
        return f'{CURRENCIES[k]}: {change}'
    if k == 'war_exhaustion':
        return f'Усталость от войны: {change}'
    if k in ('gold_gain', 'gold_loss'):
        return f"Казна: {tier} {'пополнение' if k == 'gold_gain' else 'сокращение'}"
    if k in ('manpower_gain', 'manpower_loss'):
        return f"Людские ресурсы: {tier} {'увеличение' if k == 'manpower_gain' else 'сокращение'}"
    if k == 'estate':
        return f"{ESTATES.get(a['estate'], a['estate'])}: {change} довольства"
    if k == 'all_estates':
        return f"Все сословия: {'рост' if up else 'снижение'} довольства"
    if k in ('edict_short', 'edict_long'):
        return f"Эдикт «{loc(a['edict'])}» на {years(5 if k == 'edict_short' else 15)}"
    if k in ('policy_bonus', 'policy_penalty'):
        size = {'slight': 'минимальный', 'weak': 'небольшой', 'mild': 'умеренный', 'severe': 'сильный', 'grand': 'огромный'}.get(a.get('tier'), '')
        return f"{POLICIES.get(a['area'], a['area'])}: {size} {'бонус' if k == 'policy_bonus' else 'штраф'} на {years(a['years'])}"
    if k == 'societal':
        left, _, right = a['type'].partition('_vs_')
        side = left if a['direction'].endswith('left') else right
        size = 'минимальный' if a['direction'].startswith('tiny') else 'небольшой'
        return f'Общественные ценности: {size} сдвиг в сторону «{SOCIETY.get(side, loc(side))}»'
    if k == 'character_modifier':
        return f"Собеседник получает модификатор «{loc(a['modifier'])}»"
    if k == 'opinion':
        return f"Отношение другого двора: «{loc(a['modifier'])}»"
    simple = {
        'nothing': 'Без игровых последствий', 'trust_gain': 'Доверие другого двора растёт',
        'trust_loss': 'Доверие другого двора снижается', 'favors': 'Другой двор будет обязан вам услугой',
        'gift_gold': 'Подарок золотом другому двору', 'rival_declare': 'Объявление соперничества',
        'rival_drop': 'Прекращение соперничества',
        'progress_acclaimed': 'Благоприятная память о поездке (модификатор на 5 лет)',
        'progress_resented': 'Негативная память о поездке (модификатор на 5 лет)',
    }
    if k in simple:
        return simple[k]
    if k == 'great_effort':
        return {'army': 'Все ополчения созываются в увеличенном составе на 2 года',
                'treasury': 'Пожертвования державы пополняют казну короны',
                'works': 'Всеобщие строительные усилия на 2 года',
                'faith': 'Великое возрождение веры на 2 года'}.get(a.get('domain'), 'Всеобщие усилия')
    if k in ('local_control', 'local_prosperity'):
        what = 'Контроль' if k == 'local_control' else 'Процветание'
        return f'{what} в посещённом месте: {change}'
    return k


def power(move):
    k, who = move['kind'], move.get('who', '')
    if k == 'kill':
        reason = {'execution': 'казнь', 'assassination': 'убийство', 'fever': 'смерть от лихорадки',
                  'vanished': 'исчезновение'}.get(move.get('reason'), 'смерть')
        return f'{who}: {reason}'
    if k in ('civil_war', 'civil_war_join', 'revolt'):
        what = 'Назревающий мятеж' if k == 'revolt' else 'Гражданская война'
        lead = f'; предводитель: {who}' if who else ''
        text = f"{what}: {ESTATES.get(move['estate'], move['estate'])} поднимают оружие {REGIONS.get(move['regions'], move['regions'])}{lead}"
        if k == 'civil_war_join':
            text += '. Вы переходите на сторону мятежников и возглавляете их; правитель остаётся вашим врагом.'
        return text
    return {
        'depose': f'{who}: свержение с престола', 'crown': f'{who}: восшествие на престол',
        'heir': f'{who}: назначение наследником', 'regent': f'{who}: назначение регентом',
        'to_cabinet': f'{who}: назначение в кабинет', 'from_cabinet': f'{who}: удаление из кабинета',
        'exile': f'{who}: изгнание', 'replace_ruler': f"{who}: возведение на престол державы {move.get('tag', '')}",
    }.get(k, k)


def order(offer, power_kinds):
    k = offer['kind']
    if k in power_kinds:
        return power(offer)
    if k == 'rename_country':
        return f"Новое название державы: {offer.get('name', '')}; прилагательное: {offer.get('adjective', '')}"
    if k == 'change_government':
        return f"Новая форма правления: {GOVERNMENTS.get(offer.get('government'), '')}"
    if k == 'change_rank':
        return f"Новый ранг державы: {RANKS.get(offer.get('rank'), '')}"
    return f"{ORDERS.get(k, k)} (приказ правителя)"
