"""Entry point of WhispersInTheCourt.exe (see tools/build_exe.py).

Double-clicked, it opens the Court Brain window: it installs or updates the
mod, then follows the game. The command-line options of `python -m
courtbrain` work here too.
"""

if __name__ == "__main__":
    import sys
    if len(sys.argv) == 3 and sys.argv[1] == '--verify-https':
        # Public endpoint only: no credentials, account reads or inference.
        import json
        import ssl
        import urllib.error
        import urllib.request
        from pathlib import Path
        result = {'ok': False, 'credentials_used': False, 'inference_requests': 0}
        try:
            context = ssl.create_default_context()
            assert context.check_hostname and context.verify_mode == ssl.CERT_REQUIRED
            try:
                with urllib.request.urlopen('https://generativelanguage.googleapis.com/', context=context, timeout=20) as response:
                    result['http_status'] = response.status
            except urllib.error.HTTPError as exc:
                result['http_status'] = exc.code  # An HTTP error still proves TLS completed.
                exc.close()
            result['ok'] = True
            result['tls_verified'] = True
        except Exception as exc:
            result['error_type'] = type(exc).__name__
        Path(sys.argv[2]).write_text(json.dumps(result, indent=2), encoding='utf-8')
        raise SystemExit(0 if result['ok'] else 1)
    if len(sys.argv) == 3 and sys.argv[1] == '--verify-gemini':
        # Read-only metadata check: no inference, game commands or account writes.
        import json
        import ssl
        from pathlib import Path
        from courtbrain import bundle, config
        from courtbrain.player2 import CloudClient, Player2Client
        result = {'ok': False, 'build': '0.8.5-NoDebug-EN1', 'inference_requests': 0}
        client = None
        try:
            ctx = ssl.create_default_context()
            result['tls_verified'] = ctx.check_hostname and ctx.verify_mode == ssl.CERT_REQUIRED
            cfg = config.load(bundle.config_path())
            if not cfg.gemini_api_key.strip():
                raise ValueError('Gemini key is not configured')
            voice = Player2Client(cfg.player2_base, cfg.player2_game_key)
            client = CloudClient('gemini', cfg.gemini_api_key.strip(), cfg.gemini_model, voice, timeout=20)
            names = client.models()
            result.update(ok=bool(names), model_count=len(names), selected_model_available=client.model in names)
        except Exception as exc:
            # Do not include server bodies, configuration, keys or authentication headers.
            result['error_type'] = type(exc).__name__
            result['http_status'] = getattr(exc, 'status', None)
        finally:
            if client is not None:
                client.close()
        Path(sys.argv[2]).write_text(json.dumps(result, indent=2), encoding='utf-8')
        raise SystemExit(0 if result['ok'] else 1)
    if len(sys.argv) == 3 and sys.argv[1] == "--verify-build":
        # Packaging check only: no game discovery, account access or mod installation.
        import json
        from pathlib import Path
        import ssl
        context = ssl.create_default_context()
        assert context.check_hostname and context.verify_mode == ssl.CERT_REQUIRED
        import tkinter as tk
        import jwt
        import jsonschema
        from cryptography.hazmat.primitives.asymmetric import rsa
        from courtbrain import bundle, gamedate
        from courtbrain import binarysave, nodbg_text
        from courtbrain import actions, ru_works, migrate_ru1
        from courtbrain.app import CourtBrain
        assert CourtBrain.MOD_VERSION == 8502
        assert bundle.config_path().parent.name == 'WhispersInTheCourt-NoDebug085-EN'
        actions.set_text_language('russian')
        assert '+75 золота' in actions.describe_action({'kind': 'gold_gain', 'tier': 'weak', 'gold': 75})
        assert '75 золота' in ru_works.label({'kind': 'pay', 'amount': 75}, None)
        assert binarysave.library() is not None
        assert nodbg_text.encode({'votc_out_body': 'Проверка: "текст".\nВторая строка.'})
        from courtbrain import laws
        from courtbrain.nodbg_check import test_law
        law = test_law()
        assert 'Grain Charter' in laws.loc(law)['votc_law_1']
        assert nodbg_text.encode(laws.loc(law))
        from courtbrain.chatgpt import response_payload
        from courtbrain.chatgpt_auth import _protect
        root = tk.Tk()
        root.withdraw()
        root.update_idletasks()
        root.destroy()
        assert _protect(_protect(b'build-check'), decrypt=True) == b'build-check'
        assert hasattr(jwt, 'PyJWKClient') and callable(jsonschema.validate)
        # Exercise startup in the packaged app too, with no live account/network/game.
        import tempfile
        import threading
        from unittest.mock import Mock, patch
        from courtbrain import config
        with tempfile.TemporaryDirectory() as scratch:
            cfg = config.Config(user_dir=scratch, mod_dir=str(Path(scratch)/'mod'))
            fake = Mock(NAME='Offline startup check', up=None)
            gate = threading.Event()
            fake.is_up.side_effect = lambda: gate.wait(10)
            with patch('courtbrain.app.make_client', return_value=fake), patch('courtbrain.config.user_dir_candidates_found', return_value=[]):
                brain = CourtBrain(cfg)
                brain.log = Mock()
                brain._worker = Mock()
                try:
                    brain.start()
                    assert not gate.is_set()
                    assert (cfg.run_path/'votc_nd85en_poll.txt').is_file()
                    (Path(scratch)/'console_history.txt').write_text(
                        'votc_say ACK|mail=1|loc=0|nodebug=1|achievements=1|transport=nd85en|mod=8502\n', encoding='utf-8')
                    brain.tick()
                    assert brain.game_seen
                finally:
                    brain.stop()
                    gate.set()
        report = {'ok': True, 'build': '0.8.5-NoDebug-EN1', 'game_tested': False, 'russian_files': len(list((bundle.mod_source() / 'main_menu/localization/russian').glob('*.yml'))),
                  'russian_date': gamedate.dotted('1 октября 1337'), 'variable_text_fields': len(nodbg_text.manifest()['keys']),
                  'law_text_encoding': True, 'startup_with_slow_ai': True, 'tls_context_verified': True}
        Path(sys.argv[2]).write_text(json.dumps(report), encoding='utf-8')
    else:
        mode = 'brain'
        if len(sys.argv) == 1:
            import tkinter as tk
            from tkinter import ttk
            chooser = tk.Tk()
            chooser.title('Whispers in the Court — 0.8.5 NoDebug EN1')
            chooser.geometry('540x235')
            selected = []
            def choose(value):
                selected.append(value)
                chooser.destroy()
            frame = ttk.Frame(chooser, padding=20)
            frame.pack(fill='both', expand=True)
            ttk.Label(frame, text='English edition without debug mode.\nCourt Brain is the main mode; event diagnostics do not call an AI service.', wraplength=480).pack(pady=12)
            ttk.Button(frame, text='Test events without AI', command=lambda: choose('test')).pack(fill='x', pady=8)
            ttk.Button(frame, text='Open Court Brain', command=lambda: choose('brain')).pack(fill='x', pady=8)
            chooser.mainloop()
            if not selected:
                raise SystemExit(0)
            mode = selected[0]
        elif sys.argv[1:] == ['--test-nodebug']:
            mode = 'test'
        if mode == 'test':
            from courtbrain.nodbg_check import main
            raise SystemExit(main())
        from courtbrain.__main__ import main
        raise SystemExit(main())
