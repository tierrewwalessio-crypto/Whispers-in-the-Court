"""Offline integration checks for new upstream mechanics and RU/NoDebug adapters."""
from pathlib import Path
import sys, tempfile, json
from types import SimpleNamespace
from unittest import TestCase, main
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parent/'court_brain'))
from courtbrain import actions as A, bundle, config, migrate_ru1, works, trade
from courtbrain.app import CourtBrain
from courtbrain.mailbox import Mailbox
from courtbrain.memory import Memory


class Adaptation(TestCase):
    def setUp(self):
        self.gold = dict(A.GOLD)
        A.set_text_language('russian')

    def tearDown(self):
        A.GOLD = self.gold

    def brain(self):
        b = CourtBrain.__new__(CourtBrain)
        b.log = lambda *a: None
        b.cfg = SimpleNamespace(difficulty='normal')
        return b

    def test_exact_gold_survives_validation_queue_and_russian_tooltip(self):
        A.GOLD = dict(weak=50, mild=100, severe=300)
        action, why = A.validate_action(dict(kind='gold_gain', tier='weak', gold=75))
        self.assertFalse(why)
        self.assertEqual(action['gold'],75)
        variant=A.action_variant(action)
        self.assertEqual(variant[3],75)
        lines='\n'.join(A.option_queue_lines([[variant], [], []]))
        self.assertIn('votc_queue_amount = { slot = o1_1 amount = 75 }',lines)
        self.assertIn('+75 золота',A.describe_action(action))
        self.assertIn('amount = var:votc_qa$slot$', A.variants()[variant[0]-1][1])

    def test_russian_sums_restate_to_the_actual_payment(self):
        action=dict(kind='gold_gain',tier='weak',gold_scale=dict(weak=50,mild=100,severe=300),gold_wanted=1000)
        for s in ('1 000 золота', '1\u00a0000 дукатов', '1\u202f000 рублей'):
            self.assertTrue(self.brain()._restate_sums('Выплатить '+s+'.',[action]).startswith('Выплатить 125 '))
        self.assertEqual(A.parse_sum('1\u202f500'),1500)

    def test_installments_and_balanced_transfer(self):
        b=self.brain()
        inst=b._installments_of(dict(from_='ruler'),'country','NOR')
        self.assertEqual(inst,{})
        inst=b._installments_of({'from':'ruler','gold':20,'every_months':1,'times':12},'country','NOR')
        self.assertEqual(b._installments_due(inst,'1337.1.1','1337.1.1'),1)
        self.assertEqual(b._installments_due(inst,'1337.1.1','1337.3.5'),3)
        self.assertEqual(b._installments_due(inst,'1337.1.1','1340.1.1'),12)
        self.assertEqual(b._installments_due(inst,'1337.1.1','1336.1.1'),0)
        for outgoing in (False,True):
            text=' '.join(b._installment_lines({'tag':'NOR'},40,out=outgoing))
            self.assertIn('gold >= 40',text)
            self.assertIn('add_gold = -40',text)
            self.assertIn('add_gold = 40',text)

    def test_matter_limit_closure_and_journal_reload(self):
        with tempfile.TemporaryDirectory() as tmp:
            mem=Memory(Path(tmp),123); mem.load()
            root=mem.matter_open('1337.1.1','Рыболовные угодья')
            for i in range(8): mem.add_page('1337.1.2','story',f'Этап {i}','Текст',root=root)
            self.assertEqual(mem.matter_left(root,8),0)
            mem.plan('1337.1.2',after_days=5,kind='followup',about='Спор',root=root)
            self.assertEqual(mem.end_matter_plans(root,'1337.1.3'),1)
            mem.matter_state('1337.1.3',root,'closed','Решено королём')
            mem.save(force=True)
            reopened=Memory(Path(tmp),123); reopened.load()
            self.assertEqual(reopened.matters[root]['state'],'closed')
            self.assertFalse(reopened.plans)
            self.assertIn('Рыболовные угодья',reopened.settled_brief())

    def test_delegation_accounts_for_russian_character_traits(self):
        b=self.brain()
        task=dict(who='Олаф',level=70,skill='administration',difficulty='normal')
        with patch('courtbrain.app.random.random',return_value=.4):
            honest=b._delegate_fate({**task,'traits':'Честный'})
            corrupt=b._delegate_fate({**task,'traits':'Коррумпированный'})
        self.assertGreater(honest['p'],corrupt['p'])
        self.assertTrue(corrupt['abuse'])

    def test_new_ack_pair_still_requires_text_stamp(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)
            mail=Mailbox(run_dir=p,dynamic_loc=p/'never-written.yml'); mail.ack_pair=True
            mail.send(['add_gold = 7'],loc={'votc_out_body':'Сумма: 7 золота.'})
            seq=mail.seq
            mail.ran(seq)  # snapshot alone must not release a text-dependent effect
            self.assertNotIn('add_gold = 7',(p/'votc_nd85en_poll.txt').read_text(encoding='utf-8-sig'))
            mail.acknowledge(seq,str(seq))
            sent=(p/'votc_nd85en_poll.txt').read_text(encoding='utf-8-sig')
            self.assertIn('add_gold = 7',sent)
            self.assertIn('votc_in_ack_b = yes',sent)
            mail.ran(mail.seq)
            self.assertEqual(mail.pending(),0)
            self.assertFalse((p/'never-written.yml').exists())

    def test_english_edition_does_not_import_russian_private_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); user=root/'EU5'; user.mkdir()
            old=root/'WhispersInTheCourtRU-NoDebug0812'; old.mkdir()
            original='{"ai_provider":"gemini","gemini_api_key":"DO-NOT-IMPORT"}'
            (old/'config.json').write_text(original)
            memory=user/'court_brain_nodebug0812';memory.mkdir()
            (memory/'journal.json').write_text('private')
            dest=root/'WhispersInTheCourt-NoDebug085-EN/config.json'
            own={'user_dir':str(user),'game_dir':str(root/'Game'),'player2_port':4315,'follow_game_language':False}
            dest.parent.mkdir();dest.write_text(json.dumps(own))
            before=dest.read_bytes()
            with patch.object(bundle,'config_path',return_value=dest):
                cfg=migrate_ru1.initialize()
                self.assertEqual(cfg.language,'English')
                self.assertEqual(cfg.gemini_api_key,'')
                self.assertEqual(cfg.mod_path.name,'WhispersInTheCourtNoDebug085EN')
                self.assertFalse(cfg.state_dir.exists())
                migrate_ru1.initialize()
            self.assertEqual(dest.read_bytes(),before)
            self.assertEqual((old/'config.json').read_text(),original)
            self.assertEqual((memory/'journal.json').read_text(),'private')

    def test_sponsored_payment_and_shared_cost_labels(self):
        self.assertIn('75 золота',works.label(dict(kind='pay',amount=75,from_name='Норвегия'),None))
        self.assertIn('Норвегия',works.price_text(dict(kind='build',payer_name='Норвегия',paid_by='party')))

    def test_trade_labels_match_export_and_import_effects(self):
        codex = SimpleNamespace(goods_info={'iron': {'price': 4}}, building_goods={}, word=lambda _: 'Железо')
        world = SimpleNamespace(raw_goods={'iron': 2}, buildings={})
        for direction, label, effect in [('export', 'Экспорт', 'penalty'), ('import', 'Импорт', 'bonus')]:
            result, why = trade.validate(dict(direction=direction, good='iron', volume=1, years=3,
                                             terms='fair', gold_per_month=0), codex=codex, world=world, taxbase=100)
            self.assertFalse(why)
            self.assertTrue(result['label'].startswith(label+': Железо'))
            self.assertIn(f'army_upkeep_{effect}_weak', result['lines'][0])
            self.assertIn(str(result['gold'])+' золота в месяц', result['label'])


if __name__=='__main__': main()
