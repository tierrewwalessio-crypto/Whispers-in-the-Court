"""Presentation regressions observed in the player's NoDebug game."""
import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parent / 'court_brain'))
from courtbrain import actions as A, russian_text as R, nodbg_text as T
from courtbrain.mailbox import with_gist


class RussianPolish(unittest.TestCase):
    def tearDown(self):
        A.set_text_language('russian')

    def test_decree_and_summary_do_not_duplicate_or_translate_quoted_english(self):
        self.assertEqual(R.decree_title('Указ о введении английского языка'), 'Указ о введении английского языка')
        self.assertEqual(R.decree_title('Указ:Указ о налогах'), 'Указ о налогах')
        self.assertEqual(R.decree_title('Новый совет'), 'Указ: Новый совет')
        self.assertEqual(T.prose(with_gist('In short: Барон спорит с монахами.', 'Он сказал: "In short: yes".')),
                         'Вкратце: Барон спорит с монахами.\n\nОн сказал: "In short: yes".')
        self.assertEqual(T.prose(with_gist('In short: A dispute.', 'English dialogue.')),
                         'In short: A dispute.\n\nEnglish dialogue.')

    def test_tooltip_from_fishing_dispute_and_language_switch(self):
        acts = [dict(kind='estate', estate='nobles_estate', tier='weak', sign='bonus'),
                dict(kind='estate', estate='clergy_estate', tier='weak', sign='penalty')]
        A.set_text_language('russian')
        tip = A.requested_text(acts, [])
        self.assertIn('Аристократы: небольшое повышение довольства', tip)
        self.assertIn('Священники: небольшое снижение довольства', tip)
        self.assertNotIn('asked', tip)
        A.set_text_language('english')
        self.assertIn('Nobility: satisfaction rises', A.requested_text(acts, []))

    def test_modifiers_use_russian_and_cache_follows_language(self):
        modifier = A.CHARACTER_MODIFIERS[0]
        A.set_text_language('english')
        english = A._loc(modifier)
        A.set_text_language('russian')
        russian = A._loc(modifier)
        self.assertRegex(russian, '[А-Яа-яЁё]')
        self.assertNotEqual(english, russian)
        self.assertIn(russian, A.describe_action(dict(kind='character_modifier', modifier=modifier)))

    def test_full_tooltip_fits_for_each_choice_and_preserves_script(self):
        A.set_text_language('russian')
        acts = [dict(kind='policy_penalty', area=area, tier='severe', years='20')
                for area in ('nobles_taxes', 'clergy_taxes', 'burghers_taxes', 'peasants_taxes')]
        moves = [dict(kind='civil_war_join', estate='nobles_estate', regions='foreign_culture', who='Иван Длинное Имя')]
        tip = A.requested_text(acts, moves, [A.pact_text('ruler_join_war').format(party='Исландия', enemy='Норвегия')])
        for key in ('votc_arc_req1', 'votc_arc_req2', 'votc_arc_req3', 'votc_out_requested', 'votc_chr_requested'):
            self.assertTrue(T.encode({key: tip}))
        self.assertEqual(A.render_action(acts[0]), 'votc_act_policy = { area = nobles_taxes sign = penalty tier = severe years = 20 }')
        self.assertEqual(R.years(1), '1 год')
        self.assertEqual(R.years(2), '2 года')
        self.assertEqual(R.years(20), '20 лет')


if __name__ == '__main__':
    unittest.main()
