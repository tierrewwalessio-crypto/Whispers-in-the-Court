"""Regression: a slow or broken AI health check cannot silence the game bridge."""
from pathlib import Path
import sys, tempfile, threading, time
from unittest import TestCase, main
from unittest.mock import Mock, patch
sys.path.insert(0,str(Path(__file__).resolve().parent/'court_brain'))
from courtbrain import config
from courtbrain.app import CourtBrain


class Startup(TestCase):
    def test_game_ack_is_processed_while_ai_check_is_still_waiting(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);cfg=config.Config(user_dir=str(p),mod_dir=str(p/'mod'))
            client=Mock(NAME='Slow AI',up=None)
            entered, release=threading.Event(),threading.Event()
            def health():
                entered.set();release.wait(5);return False
            client.is_up.side_effect=health
            with patch('courtbrain.app.make_client',return_value=client),patch('courtbrain.config.user_dir_candidates_found',return_value=[]):
                brain=CourtBrain(cfg);brain.log=Mock()
                brain._worker=Mock()  # no story tasks or inference in the test
                try:
                    start=time.monotonic();brain.start()
                    self.assertLess(time.monotonic()-start,1.0)
                    self.assertTrue(entered.wait(1))
                    self.assertTrue((cfg.run_path/'votc_nd85en_poll.txt').is_file())
                    self.assertFalse(release.is_set())
                    with (p/'console_history.txt').open('a',encoding='utf-8') as f:
                        f.write('votc_say ACK|mail=1|loc=0|nodebug=1|achievements=1|transport=nd85en|mod=8502\n')
                    brain.tick()
                    self.assertTrue(brain.game_seen)
                    self.assertEqual(brain._achievement_status,'1')
                    self.assertFalse(release.is_set())
                finally:
                    brain.stop();release.set()

    def test_ai_check_exception_is_reported_without_stopping_bridge(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg=config.Config(user_dir=tmp,mod_dir=str(Path(tmp)/'mod'))
            client=Mock(NAME='Broken AI',up=None)
            client.is_up.side_effect=RuntimeError('metadata failure')
            with patch('courtbrain.app.make_client',return_value=client),patch('courtbrain.config.user_dir_candidates_found',return_value=[]):
                brain=CourtBrain(cfg);messages=[];brain.log=messages.append;brain._worker=Mock()
                try:
                    brain.start()
                    deadline=time.monotonic()+1
                    while client.up is not False and time.monotonic()<deadline: time.sleep(.01)
                    self.assertIs(client.up,False)
                    self.assertTrue(any('Connection check failed for Broken AI' in s for s in messages))
                    self.assertTrue((cfg.run_path/'votc_nd85en_poll.txt').is_file())
                finally: brain.stop()

    def test_startup_exception_is_visible_in_log_and_status(self):
        brain=CourtBrain.__new__(CourtBrain)
        brain.start=Mock(side_effect=OSError('run directory unavailable'));brain.log=Mock();brain._ui=Mock()
        brain.run_forever()
        self.assertTrue(brain._startup_error)
        self.assertIn('run directory unavailable',brain.log.call_args.args[0])
        brain._ui.assert_called_once()

    def test_steam_library_without_manifest_is_discoverable(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);game=p/'steamapps/common/Europa Universalis V';(game/'game/in_game').mkdir(parents=True)
            with patch('courtbrain.config._home',return_value=p),patch('courtbrain.config.Path',side_effect=lambda x: p if x=='C:/Program Files (x86)/Steam' else Path(x)):
                self.assertEqual(config.discover_game_dir(),game)


if __name__=='__main__': main()
