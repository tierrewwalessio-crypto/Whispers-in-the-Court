"""Generate static localization once, before building/installing the mod."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
LOC = ROOT / 'mod/WhispersInTheCourt/main_menu/localization'
PACKAGE = ROOT / 'tools/court_brain/courtbrain'
PAT = re.compile(r'^ ([\w.]+):0 "(.*)"$', re.M)
STEMS = ('votc_dynamic', 'votc_names', 'votc_lnames')


def capacity(key):
    if key in ('votc_cen_body', 'votc_obt_body', 'votc_chr_body'):
        return 4096
    if '_requested' in key or key.startswith('votc_arc_req'):
        return 1024
    if key.endswith('_body'):
        return 2048
    if key.startswith(('votc_cname_', 'votc_lname_')):
        return 64
    return 128


def main():
    manifest_path = PACKAGE / 'nodbg_manifest.json'
    if manifest_path.exists():
        data = json.loads(manifest_path.read_text(encoding='utf-8'))
    else:
        languages = {}
        for language in ('english', 'russian'):
            languages[language] = {}
            for stem in STEMS:
                p = LOC / language / f'{stem}_l_{language}.yml'
                if not p.exists():
                    p = LOC / 'english' / f'{stem}_l_english.yml'
                if p.exists():
                    languages[language][stem] = dict(PAT.findall(p.read_text(encoding='utf-8-sig')))
                elif stem == 'votc_lnames':
                    languages[language][stem] = {f'votc_lname_{n}': 'Whispers in the Court' for n in range(1, 401)}
                else:
                    raise FileNotFoundError(p)
        keys = sorted({k for values in languages['english'].values() for k in values if k != 'votc_loc_stamp'})
        data = {'version': 1, 'keys': {k: {'id': i, 'capacity': capacity(k)} for i, k in enumerate(keys)}, 'fallbacks': languages}
        manifest_path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
    for language, stems in data['fallbacks'].items():
        helpers = [f'l_{language}:', ' vnd_empty:0 ""']
        for n in [9, 10, *range(32, 127)]:
            value = chr(n).replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\t', '    ')
            # Dynamic AI prose brackets/hash/dollar are neutralized before encoding.
            if n in (35, 36, 91, 93):
                value = chr(n + 0xfee0)
            helpers.append(f' vnd_c{n:03d}:0 "{value}"')
        for stem, values in stems.items():
            lines = [f'l_{language}:']
            for key, fallback in values.items():
                if key == 'votc_loc_stamp':
                    lines.append(' votc_loc_stamp:0 "[GetGlobalVariable(\'vnd_stamp\').GetValue|0]"')
                    continue
                entry = data['keys'][key]
                ident, cap = entry['id'], entry['capacity']
                lines.append(f' {key}:0 "[SelectLocalization(GetGlobalVariable(\'vnd_{ident}_ready\').IsSet, \'vnd_{ident}_live\', \'vnd_{ident}_fallback\')]"')
                helpers.append(f' vnd_{ident}_fallback:0 "{fallback}"')
                helpers.append(f' vnd_{ident}_live:0 "' + ''.join(f'$vnd_{ident}_g{n}$' for n in range(cap // 32)) + '"')
                for group in range(cap // 32):
                    helpers.append(f' vnd_{ident}_g{group}:0 "' + ''.join(
                        f"[GetGlobalVariable('vnd_{ident}_{n}').GetFlagName]" for n in range(group * 32, (group + 1) * 32)) + '"')
            (LOC / language / f'{stem}_l_{language}.yml').write_text('\n'.join(lines) + '\n', encoding='utf-8-sig')
        (LOC / language / f'votc_nd_text_l_{language}.yml').write_text('\n'.join(helpers) + '\n', encoding='utf-8-sig')
    print('Static variable text fields:', len(data['keys']))


if __name__ == '__main__':
    main()
