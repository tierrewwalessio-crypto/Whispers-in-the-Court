"""Offline checks. No game launch, account access, or inference requests."""
import json
from pathlib import Path
import re
import tempfile
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / 'court_brain'))
from courtbrain import nodbg_text as text, bundle, config, binarysave
from courtbrain.mailbox import Mailbox
from courtbrain.nodbg_check import LONG_TEXT, SHORT_TEXT

ROOT = Path(__file__).resolve().parents[1]


class Transport(unittest.TestCase):
    def render(self, value, key='votc_out_body'):
        """Resolve the generated static fragments, independent of the encoder."""
        variables = {}
        for line in text.encode({key: value}):
            m = re.fullmatch(r'set_global_variable = \{ name = (\w+) value = "flag:(.*)" \}', line)
            if m:
                # Match the engine: raw flag names lose boundary whitespace.
                variables[m[1]] = m[2].strip()
        loc = (bundle.mod_source() / 'main_menu/localization/russian/votc_nd_text_l_russian.yml').read_text(encoding='utf-8-sig')
        keys = dict(re.findall(r'^ (\w+):0 "(.*)"$', loc, re.M))
        ident = text.manifest()['keys'][key]['id']
        body = keys[f'vnd_{ident}_live']
        body = re.sub(r'\$(\w+)\$', lambda m: keys[m[1]], body)
        body = re.sub(r"\[GetGlobalVariable\('([^']+)'\).GetFlagName\]", lambda m: keys.get(variables[m[1]], variables[m[1]]), body)
        return body.replace('\\n', '\n').replace('\\"', '"').replace('\\\\', '\\')

    def test_punctuation_quotes_paragraphs_and_long_text(self):
        for value in (LONG_TEXT, SHORT_TEXT, 'ENG', 'yes', '1.5: "Да"; путь C:\\Games\\EU5', 'A' * 150, '  Совет, посол; затем: мир. Следующий день.  ',
                      'С' * 159 + ' ' + 'два слова ' * 40, '"  Да  "',
                      'Символы [пример] #test $name$ — безопасный текст'):
            self.assertEqual(self.render(value), text.prose(value))

    def test_short_text_clears_every_tail_slot(self):
        lines = text.encode({'votc_out_body': SHORT_TEXT})
        cap = text.manifest()['keys']['votc_out_body']['capacity']
        self.assertEqual(len(lines), cap + 1)
        self.assertIn('flag:vnd_empty', lines[-2])

    def test_refuses_oversized_or_unknown_text_before_sending_effects(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            mail = Mailbox(run_dir=root/'run', dynamic_loc=root/'dynamic.yml')
            mail.reset_files()
            before = (root/'run/votc_nd85en_poll.txt').read_bytes()
            for values in ({'not_registered': 'text'}, {'votc_out_title': '.' * 1000}):
                with self.assertRaises(ValueError):
                    mail.send(['add_gold = 100'], loc=values)
                self.assertEqual(mail.pending(), 0)
                self.assertEqual((root/'run/votc_nd85en_poll.txt').read_bytes(), before)

    def test_effects_wait_for_matching_stamp(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            mail = Mailbox(run_dir=root, dynamic_loc=root/'untouched.yml')
            mail.send(['trigger_event_non_silently = { id = wicnd.1 }'], loc={'votc_out_body': LONG_TEXT})
            body = (root/'votc_nd85en_poll.txt').read_text(encoding='utf-8-sig')
            self.assertNotIn('trigger_event_non_silently', body)
            self.assertNotIn('reload', body)
            self.assertFalse((root/'untouched.yml').exists())
            stamp = mail.seq
            mail.acknowledge(stamp, str(stamp))
            body = (root/'votc_nd85en_poll.txt').read_text(encoding='utf-8-sig')
            self.assertIn('id = wicnd.1', body)
            mail.acknowledge(mail.seq, str(stamp))
            self.assertEqual(mail.pending(), 0)

    def test_bad_or_missing_stamp_never_releases_event(self):
        for answer in ('0', 'ERROR_FLAG_INDEX', None):
            with self.subTest(answer=answer), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                mail = Mailbox(run_dir=root, dynamic_loc=root/'unused')
                mail.send(['add_gold = 100'], loc={'votc_out_body': 'Проверка.'})
                for attempt in range(25):
                    mail.acknowledge(mail.seq, answer)
                    for item in mail._queue:
                        item.not_before = 0
                    if mail._in_flight:
                        mail._sent_at = 0
                    mail.pump()
                    self.assertNotIn('add_gold', (root/'votc_nd85en_poll.txt').read_text(encoding='utf-8-sig'))
                self.assertTrue(mail.stamp_check)

    def test_names_use_same_transport(self):
        self.assertEqual(self.render('Новое королевство: «Север».', 'votc_cname_1'), 'Новое королевство: «Север».')
        self.assertEqual(self.render('Санкт-Петербург', 'votc_lname_400'), 'Санкт-Петербург')

    def test_installation_and_memory_are_separate(self):
        cfg = config.Config(user_dir='C:/test')
        self.assertEqual(cfg.state_dir.name, 'court_brain_nodebug085_en')
        with patch.object(bundle, 'frozen', return_value=True):
            self.assertEqual(bundle.config_path().parent.name, 'WhispersInTheCourt-NoDebug085-EN')
        source = (ROOT/'tools/court_brain/courtbrain/bundle.py').read_text(encoding='utf-8')
        launch = source.split('def launch_game', 1)[1].split('_MUTEX =', 1)[0]
        self.assertNotIn('-debug_mode', launch)
        self.assertIn('WhispersInTheCourtNoDebug085EN', source)

    def test_static_bridge_uses_new_protocol_and_no_reload(self):
        for p in bundle.mod_source().rglob('votc_bridge_l_*.yml'):
            data = p.read_text(encoding='utf-8-sig')
            self.assertNotIn('reload switchlanguage', data)
            self.assertIn('|transport=nd85en|achievements=', data)
        meta = json.loads((bundle.mod_source()/'.metadata/metadata.json').read_text(encoding='utf-8'))
        self.assertEqual(meta['id'], 'wic_nodebug_085_en')
        runtime = (bundle.mod_source()/'in_game/common/script_values/votc_runtime_values.txt').read_text(encoding='utf-8-sig')
        self.assertRegex(runtime, r'votc_v_modver\s*=\s*\{\s*value\s*=\s*8502\s*\}')

    def test_binary_library_is_present(self):
        self.assertTrue(binarysave.library())


if __name__ == '__main__':
    unittest.main()
