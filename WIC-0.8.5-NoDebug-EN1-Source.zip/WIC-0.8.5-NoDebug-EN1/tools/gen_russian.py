"""Rebuild Russian localization after the upstream generators (no AI service needed)."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def table(name):
    return dict(line.split(" => ", 1) for line in (ROOT / "tools" / name).read_text(encoding="utf-8").splitlines()
                if " => " in line)


WORDS = table("ru_game.txt")
TERMS = table("ru_terms.txt")
LOWER = {k.lower(): v.lower() for k, v in TERMS.items()}
STRENGTH = {"minor": "слабый", "moderate": "умеренный", "major": "сильный", "great": "огромный"}


def translate(value):
    if value in WORDS:
        return WORDS[value]
    match = re.fullmatch(r"(.+): (minor|moderate|major|great) (disadvantage|advantage)", value)
    if match:
        term, strength, direction = match.groups()
        return TERMS[term] + ": " + STRENGTH[strength] + (" штраф" if direction == "disadvantage" else " бонус")
    match = re.fullmatch(r"(\$[^$]+\$): (its burden on )?(.+) \((minor|moderate|major)\)", value)
    if match:
        key, burden, term, strength = match.groups()
        return f"{key}: {LOWER[term]} ({STRENGTH[strength]} {'штраф' if burden else 'эффект'})"
    match = re.fullmatch(r"(\$[^$]+\$): its cost \((\d+)% of the tax income\)", value)
    if match:
        return f"{match[1]}: содержание ({match[2]}% налогового дохода)"
    if value.endswith(" (by decree)"):
        return value[:-12] + " (по указу)"
    match = re.fullmatch(r"(.+) (I|II|III|\d+)", value)
    if match and match[1] in WORDS:
        return WORDS[match[1]] + " " + match[2]
    if value.startswith(("What you decided", "What was agreed")):
        for en, ru in sorted(WORDS.items(), key=lambda item: -len(item[0])):
            value = value.replace(en, ru)
    return value


def main():
    root = ROOT / "mod/WhispersInTheCourt/main_menu/localization"
    (root / "russian").mkdir(exist_ok=True)
    total = 0
    missed = set()
    for file in (root / "english").glob("*.yml"):
        lines = []
        for line in file.read_text(encoding="utf-8-sig").splitlines():
            match = re.fullmatch(r'(\s+[\w.]+:\d* )"(.*)"', line)
            if match and "bridge" not in file.name:
                original = match[2]
                value = translate(original)
                total += value != original
                visible = re.sub(r"\$[^$]+\$|\[[^\]]+\]|#[A-Za-z_]+|#!|\\n|\b(?:I|II|III)\b", "", value)
                visible = visible.replace("Court Brain", "").replace("EU5", "").replace("-debug_mode", "").replace("Steam", "").replace("Europa Universalis V", "")
                if re.search(r"[A-Za-z]", visible) and original != "CATEGORY_FRIENDLY_ACTIONS":
                    missed.add(original)
                line = match[1] + '"' + value + '"'
            lines.append(line.replace("l_english:", "l_russian:", 1) if line == "l_english:" else line)
        (root / "russian" / file.name.replace("_english", "_russian")).write_text(
            "\n".join(lines) + "\n", encoding="utf-8-sig", newline="\n")
    print(f"Russian localization: {total} translated entries; {len(missed)} untranslated values")
    for item in sorted(missed):
        print(item)
    return 1 if missed else 0


if __name__ == "__main__":
    raise SystemExit(main())
