"""Offline regression checks; no account, game or real user settings are touched."""
import io
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch, Mock
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools/court_brain'))
from courtbrain import bundle, gamedate, prompts
from courtbrain.config import Config, load
from courtbrain.chatgpt_auth import AccountStore, AuthError, PLAN_SCOPE, ISSUER, sign_in, validate_identity
from courtbrain.chatgpt import ChatGPTClient, read_response, response_payload
from courtbrain.player2 import Player2Error, make_client
from courtbrain.mailbox import Mailbox

SCHEMA = {'type': 'object', 'properties': {'answer': {'type': 'string'}}, 'required': ['answer'], 'additionalProperties': False}
def event(kind='response.completed', text='{"answer":"Готово"}', status='completed'):
    return ('data: ' + json.dumps({'type': kind, 'response': {'status': status, 'output': [
        {'type': 'message', 'content': [{'type': 'output_text', 'text': text}]}]}}) + '\n\n').encode()

class Checks(unittest.TestCase):
    def setUp(self):
        (ROOT / 'work').mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / 'work')
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)

    def test_dates_all_russian_months(self):
        for i, month in enumerate('января февраля марта апреля мая июня июля августа сентября октября ноября декабря'.split(), 1):
            self.assertEqual(gamedate.parse(f'08:00, 17 {month}, 1337'), (1337, i, 17))
        self.assertEqual(gamedate.dotted('17 октября 1337 г.'), '1337.10.17')
        self.assertEqual(gamedate.parse('08:00, 1 April, 1337'), (1337, 4, 1))

    def test_follows_game_language(self):
        settings = self.path / 'pdx_settings.json'
        settings.write_text(json.dumps({'System': {'language': 'l_russian'}}))
        cfgfile = self.path / 'config.json'
        cfgfile.write_text(json.dumps({'user_dir': str(self.path), 'game_dir': str(self.path), 'player2_port': 4315}))
        self.assertEqual(load(cfgfile).game_language, 'russian')
        self.assertEqual(load(cfgfile).reload_command, 'reload switchlanguage russian')

    def test_russian_numbers_and_cyrillic_protocol(self):
        from courtbrain.protocol import number, parse_line
        from courtbrain.world import _as_float
        for text,expected in [('12 345',12345),('12\u00a0345,67',12345.67),('−1,25',-1.25),('1,234',1234),('1,234.56',1234.56),('2,50%',2.5)]:
            self.assertEqual(number(text),expected)
            self.assertEqual(_as_float(text),expected)
        rec=parse_line('votc_say HEAD|MOS|Москва|date=1 октября 1337')
        self.assertEqual(rec.positional[1],'Москва')
        self.assertEqual(gamedate.parse(rec.fields['date']),(1337,10,1))

    def test_codex_cache_separates_languages(self):
        from courtbrain import codex
        with patch.object(codex,'build',side_effect=lambda g,l: codex.Codex(game_dir=str(g),loc={'title':l})) as build:
            codex.load_or_build('test-game',self.path,'english')
            ru=codex.load_or_build('test-game',self.path,'russian')
            self.assertEqual(ru.loc['title'],'russian')
            self.assertEqual(build.call_count,2)

    def test_localization_preserves_keys_and_substitutions(self):
        loc = bundle.mod_source() / 'main_menu/localization'
        def entries(p):
            return dict(re.findall(r'^\s+([\w.]+):\d*\s+"(.*)"', p.read_text(encoding='utf-8-sig'), re.M))
        def tokens(s):
            return sorted(re.findall(r'\[[^\]\n]+\]|\$[^$\n]+\$|@[\w!]+', s))
        for en in (loc / 'english').glob('*.yml'):
            ru = loc / 'russian' / en.name.replace('_l_english', '_l_russian')
            self.assertTrue(ru.read_bytes().startswith(b'\xef\xbb\xbf'))
            a, b = entries(en), entries(ru)
            self.assertEqual(set(a), set(b), en.name)
            for k in a:
                self.assertEqual(tokens(a[k]), tokens(b[k]), k)
        target = self.path / 'mod'
        shutil.copytree(bundle.mod_source(), target)
        bundle._localize(target, Config(game_language='russian'))
        dynamic = target / 'main_menu/localization/russian/votc_dynamic_l_russian.yml'
        mailbox = Mailbox(run_dir=self.path / 'run', dynamic_loc=dynamic, language_key='l_russian')
        self.assertTrue(any(re.search('[А-Яа-я]', v) for v in mailbox.fallbacks.values()))
        before = dynamic.read_bytes()
        mailbox.send([], loc={'votc_out_body': 'Новый русский ответ: готово.'})
        self.assertEqual(dynamic.read_bytes(), before)
        self.assertIn('set_global_variable', (self.path/'run/votc_nd85en_poll.txt').read_text(encoding='utf-8-sig'))
        bridge = '\n'.join(p.read_text(encoding='utf-8-sig') for p in (target/'main_menu/localization/russian').glob('*bridge*'))
        self.assertNotIn('reload switchlanguage', bridge)
        self.assertIn('transport=nd85en', bridge)

    def test_encrypted_storage_refresh_logout(self):
        store = AccountStore(self.path / 'tokens.dpapi')
        host = store.snapshot()['host_id']
        record = {'subject': 'test', 'access_token': 'SECRET_TEST_ACCESS', 'refresh_token': 'SECRET_TEST_REFRESH',
                  'expires_at': 0, 'scopes': [PLAN_SCOPE]}
        store.save_account('test-client', record)
        self.assertNotIn(b'SECRET_TEST', store.path.read_bytes())
        with patch('courtbrain.chatgpt_auth.request_json', return_value={'access_token': 'rotated', 'refresh_token': 'rotated-refresh', 'expires_in': 3600}) as req:
            self.assertEqual(store.access_token('test-client'), 'rotated')
            self.assertEqual(req.call_args.args[1]['client_id'], 'test-client')
            self.assertNotIn('scope', req.call_args.args[1])
            self.assertEqual(store.access_token('test-client'), 'rotated')
            self.assertEqual(req.call_count, 1)
        with patch('courtbrain.chatgpt_auth.request_json', side_effect=AuthError('offline')):
            self.assertFalse(store.sign_out('test-client'))
        self.assertEqual(store.snapshot()['host_id'], host)
        self.assertIn('test-client', store.snapshot()['accounts'])
        with self.assertRaises(AuthError): store.access_token('test-client')

    def test_scope_required(self):
        store = AccountStore(self.path / 'tokens.dpapi')
        store.save_account('client', {'access_token': 'test', 'expires_at': time.time()+3600, 'scopes': []})
        with self.assertRaises(AuthError): store.access_token('client')

    def test_jwt_signature_audience_expiry_nonce(self):
        import jwt
        from cryptography.hazmat.primitives.asymmetric import rsa
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        good = dict(iss=ISSUER, aud='client', exp=time.time()+100, sub='subject', nonce='nonce')
        with patch('jwt.PyJWKClient') as jwks:
            jwks.return_value.get_signing_key_from_jwt.return_value.key = key.public_key()
            encoded = jwt.encode(good, key, algorithm='RS256')
            self.assertEqual(validate_identity(encoded, 'client', 'nonce')['sub'], 'subject')
            for changes in ({'aud': 'wrong'}, {'exp': 1}, {'nonce': 'wrong'}, {'iss': 'wrong'}):
                with self.assertRaises(AuthError):
                    validate_identity(jwt.encode(good | changes, key, algorithm='RS256'), 'client', 'nonce')

    def test_loopback_pkce_and_wrong_state_rejected(self):
        store = AccountStore(self.path / 'tokens.dpapi')
        seen, results = {}, []
        cancel = threading.Event()
        def browser(url):
            q = {k:v[0] for k,v in urllib.parse.parse_qs(urllib.parse.urlparse(url).query).items()}
            seen.update(q)
            def callback():
                try:
                    for state in ('wrong-state', q['state']):
                        u=q['redirect_uri']+'?'+urllib.parse.urlencode({'state':state,'code':'test-code','client_id':'issued-client'})
                        try:
                            with urllib.request.urlopen(u,timeout=3) as r: results.append(r.status)
                        except urllib.error.HTTPError as e:results.append(e.code)
                finally: cancel.set()
            threading.Thread(target=callback,daemon=True).start()
            return True
        with patch('courtbrain.chatgpt_auth.request_json', return_value={'access_token':'test','id_token':'test-id','scope':PLAN_SCOPE,'expires_in':3600}) as req, patch('courtbrain.chatgpt_auth.validate_identity',return_value={'sub':'verified'}):
            self.assertEqual(sign_in(store,open_browser=browser,cancel=cancel),'issued-client')
            fields = req.call_args.args[1]
            import base64, hashlib
            actual = base64.urlsafe_b64encode(hashlib.sha256(fields['code_verifier'].encode()).digest()).decode().rstrip('=')
            self.assertEqual(actual,seen['code_challenge'])
            self.assertEqual(fields['redirect_uri'],seen['redirect_uri'])
            self.assertEqual(fields['client_id'],'issued-client')
        self.assertEqual(results,[400,200])

    def test_sse_requires_successful_terminal_event(self):
        self.assertEqual(json.loads(read_response(io.BytesIO(event()))[0])['answer'],'Готово')
        for data in (b'data: [DONE]\n\n', event('response.incomplete'), event('response.failed'), event(status='incomplete'), b'data: invalid\n\n'):
            with self.assertRaises(Player2Error): read_response(io.BytesIO(data))

    def test_payload_schema_and_no_fallback(self):
        p=response_payload([{'role':'system','content':'правила'}],SCHEMA,'model','test')
        self.assertEqual(p['input'][0]['role'],'developer')
        self.assertIs(p['store'],False)
        self.assertIs(p['stream'],True)
        self.assertNotIn('max_output_tokens',p)
        cfg=Config(ai_provider='chatgpt', chatgpt_model='test', chatgpt_account='client',player2_port=4315)
        self.assertIsInstance(make_client(cfg),ChatGPTClient)
        client=ChatGPTClient(cfg,Mock(),store=Mock(access_token=Mock(return_value='test')))
        for body,ok in (('{"answer":"Готово"}',True),('{"wrong":"field"}',False)):
            with patch('urllib.request.urlopen',return_value=io.BytesIO(event(text=body))):
                if ok:self.assertEqual(client.complete_json([],SCHEMA),{'answer':'Готово'})
                else:
                    with self.assertRaises(Player2Error):client.complete_json([],SCHEMA)

    def test_streamed_text_with_empty_completed_output(self):
        def sse(obj): return ('data: '+json.dumps(obj)+'\n\n').encode()
        terminal=sse({'type':'response.completed','response':{'status':'completed','output':[]}})
        chunks=[sse({'type':'response.output_text.delta','output_index':0,'content_index':0,'delta':x}) for x in ('{"answer":','"Готово"}')]
        done=sse({'type':'response.output_text.done','output_index':0,'content_index':0,'text':'{"answer":"Готово"}'})
        item=sse({'type':'response.output_item.done','output_index':0,'item':{'type':'message','content':[{'type':'output_text','text':'{"answer":"Готово"}'}]}})
        for text_events in (b''.join(chunks),b''.join(chunks)+done,b''.join(chunks)+done+item,done,item):
            self.assertEqual(json.loads(read_response(io.BytesIO(text_events+terminal))[0]),{'answer':'Готово'})
            with self.assertRaises(Player2Error):read_response(io.BytesIO(text_events))
        failed=sse({'type':'response.failed','response':{'status':'failed','error':{'code':'subscription_sharing_usage_limit_exceeded'}}})
        with self.assertRaises(Player2Error):read_response(io.BytesIO(done+failed))
        with self.assertRaises(Player2Error):read_response(io.BytesIO(terminal))

    def test_streamed_refusal_is_not_success(self):
        refusal=b'data: {"type":"response.refusal.done","refusal":"no"}\n\n'
        with self.assertRaises(Player2Error):read_response(io.BytesIO(refusal+event()))

    def test_settings_ui_pages_and_chatgpt_save(self):
        import tkinter as tk
        from courtbrain.drawer import Art
        from courtbrain.ledger import Ledger
        root=tk.Tk()
        root.withdraw()
        self.addCleanup(root.destroy)
        failures=[]
        root.report_callback_exception=lambda *e: failures.append(e)
        cfg=Config(player2_port=4315)
        saved={}
        store=AccountStore(self.path/'ui.dpapi')
        with patch('courtbrain.chatgpt_ui.AccountStore',return_value=store):
            window=Ledger(root,Art(root,'',None),cfg=cfg,log_file=None,data_dir=None,save_option=saved.__setitem__)
            window.show_setup(first=False)
            for step in range(5):
                window._step=step
                window._draw_step()
                root.update()
            window.show_ai()
            window._pick('provider','chatgpt')
            root.update()
            self.assertTrue(window._chatgpt_panel.winfo_exists())
            window._finish()
            self.assertNotIn('ai_provider',saved)
            window._choices.update(chatgpt_account='test-client',chatgpt_model='test-model')
            window._finish()
            self.assertEqual(saved['ai_provider'],'chatgpt')
            self.assertEqual(saved['chatgpt_model'],'test-model')
            root.update()
        self.assertFalse(failures)

if __name__ == '__main__': unittest.main(verbosity=2)
