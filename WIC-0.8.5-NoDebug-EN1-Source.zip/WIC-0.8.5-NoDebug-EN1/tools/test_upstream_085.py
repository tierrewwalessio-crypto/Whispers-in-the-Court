"""New 0.8.5 mechanics and adaptation boundaries, without any AI or game calls."""
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from unittest import TestCase, main
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parent/'court_brain'))
from courtbrain import actions as A, laws as L, nodbg_text, bundle, config, migrate_ru1, prompts
from courtbrain.app import CourtBrain
from courtbrain.memory import Memory
from courtbrain.mailbox import Mailbox
from courtbrain.world import Snapshot
from courtbrain.player2 import make_client, CloudClient, Player2Client, _json_in
from courtbrain.ledger import _missing, PROVIDER_FIELDS
import jsonschema


def raw_law():
    return {'action': 'create', 'name': 'Устав зерновых складов', 'about': 'Правила помощи голодающим.',
            'options': [dict(name='Сохранить обычай', desc='Помощь остаётся добровольной.', gains=[], costs=[], values=[]),
                        dict(name='Открыть склады', desc='Корона помогает деревням: выдаёт зерно, принимает расписки.',
                             gains=[dict(area='peasants_favour', strength=3)], costs=[dict(area='taxation', strength=1)],
                             values=[dict(value='free_subjects', strength=1)]),
                        dict(name='Монастырское попечение', desc='Запасы распределяет духовенство.',
                             gains=[dict(area='clergy_favour', strength=1)], costs=[dict(area='crown_power', strength=1)], values=[]),
                        dict(name='Общинные амбары', desc='Города и деревни создают общие запасы.',
                             gains=[dict(area='food', strength=2)], costs=[dict(area='taxation', strength=2)], values=[])]}


class Release085(TestCase):
    def setUp(self):
        A.set_text_language('russian')

    def brain(self):
        brain = CourtBrain.__new__(CourtBrain)
        brain.log = lambda *_: None
        brain.memory = None
        return brain

    def test_law_balancing_localization_and_all_slots(self):
        raw=raw_law(); jsonschema.validate([raw],L.schema())
        law, why=L.validate(raw,{})
        self.assertFalse(why)
        for o in law['options'][1:]:
            self.assertLessEqual(abs(sum(g['strength'] for g in o['gains'])-sum(c['strength'] for c in o['costs'])),1)
        self.assertFalse(law['options'][0]['gains'])
        for slot in range(1,5):
            values=L.loc({**law,'slot':slot})
            self.assertEqual(len(values),14)
            self.assertIn('После полного вступления в силу',values[f'votc_law_{slot}_p2_desc'])
            self.assertTrue(nodbg_text.encode(values))
        self.assertIn('Новый закон',L.label(law))

    def test_new_law_scripts_wait_for_the_matching_text_ack(self):
        law,_=L.validate(raw_law(),{})
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp); m=Mailbox(run_dir=p,dynamic_loc=p/'never-written.yml')
            m.send(L.script(law,None),loc=L.loc(law))
            poll=p/'votc_nd85en_poll.txt'
            self.assertNotIn('votc_lw1_on',poll.read_text(encoding='utf-8-sig'))
            seq=m.seq;m.acknowledge(seq,str(seq))
            self.assertIn('name = votc_lw1_on value = 1',poll.read_text(encoding='utf-8-sig'))
            self.assertFalse((p/'never-written.yml').exists())

    def test_law_memory_rewrite_repeal_and_restoration(self):
        law,_=L.validate(raw_law(),{})
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);mem=Memory(p,123);mem.load();mem.law_set('1337.1.1',law);mem.save(force=True)
            other=Memory(p,123);other.load();self.assertEqual(other.laws[1]['name'],law['name'])
            rewritten,_=L.validate(raw_law(),other.laws)
            self.assertEqual(rewritten['slot'],1)
            repeal,why=L.validate(dict(action='repeal',name=law['name']),other.laws)
            self.assertFalse(why)
            self.assertIn('remove_variable = votc_lw1_on',L.script(repeal,law))
            # Restore names from the journal when the next scene is sent.
            m=Mailbox(run_dir=p/'run',dynamic_loc=p/'unused.yml');m.loc_values.update(L.loc(other.laws[1]))
            m.send(['votc_show_outcome = yes'],loc={'votc_out_body':'После загрузки.'})
            ident=nodbg_text.manifest()['keys']['votc_law_1']['id']
            self.assertIn(f'vnd_{ident}_ready',(p/'run/votc_nd85en_poll.txt').read_text(encoding='utf-8-sig'))
            other.law_end('1337.2.1',1);other.save(force=True)
            final=Memory(p,123);final.load();self.assertFalse(final.laws)

    def test_deed_local_consequences_and_russian_military_context(self):
        b=self.brain()
        lines,labels=b._deed_choice(Snapshot(),dict(where='Рейкьявик',where_key='reykjavik'),
                                  dict(place_change=dict(control=9,prosperity=-1)))
        self.assertIn('votc_act_local_control = { tier = mild sign = bonus }',lines)
        self.assertIn('votc_act_local_prosperity = { tier = weak sign = penalty }',lines)
        self.assertEqual(len(labels),2)
        self.assertTrue(b._MILITARY_DEED.search('Провести смотр войск и посетить казармы'))
        self.assertIn('place_change',prompts.story_event_schema(deed=True)['properties']['options']['items']['properties'])

    def test_local_decree_rewards_and_recent_rewards_are_limited(self):
        b=self.brain();snap=Snapshot(date='1337.1.1',numbers={'taxbase':1000})
        reach=dict(scope='place',keys=['reykjavik'],tax=1)
        local=b._earned(snap,'triumph',2,reach)
        realm=b._earned(snap,'triumph',2,dict(scope='realm'))
        self.assertEqual(local['grand_left'],0)
        self.assertEqual(local['income'],'weak')
        self.assertLessEqual(local['band'],realm['band'])
        with patch.object(b,'_earned_lately',return_value=[dict(places=['reykjavik'],income=True)]):
            self.assertIsNone(b._earned(snap,'triumph',2,reach))

    def test_english_edition_does_not_import_russian_private_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); user=root/'EU5'; user.mkdir()
            old=root/'WhispersInTheCourtRU-NoDebug0812'; old.mkdir()
            original='{"ai_provider":"gemini","gemini_api_key":"DO-NOT-IMPORT"}'
            (old/'config.json').write_text(original)
            memory=user/'court_brain_nodebug0812';memory.mkdir()
            (memory/'journal.json').write_text('private')
            dest=root/'WhispersInTheCourt-NoDebug085-EN/config.json'
            own={'user_dir':str(user),'game_dir':str(root/'Game'),'player2_port':4315,'follow_game_language':False}
            dest.parent.mkdir();dest.write_text(json.dumps(own))
            before=dest.read_bytes()
            with patch.object(bundle,'config_path',return_value=dest):
                cfg=migrate_ru1.initialize()
                self.assertEqual(cfg.language,'English')
                self.assertEqual(cfg.gemini_api_key,'')
                self.assertEqual(cfg.mod_path.name,'WhispersInTheCourtNoDebug085EN')
                self.assertFalse(cfg.state_dir.exists())
                migrate_ru1.initialize()
            self.assertEqual(dest.read_bytes(),before)
            self.assertEqual((old/'config.json').read_text(),original)
            self.assertEqual((memory/'journal.json').read_text(),'private')

    def test_custom_provider_needs_address_not_key_and_keeps_json_parsing(self):
        cfg=config.Config(ai_provider='custom',custom_base_url='http://localhost:1234/v1/chat/completions',custom_api_key='',custom_model='local-model')
        client=make_client(cfg)
        self.assertIsInstance(client,CloudClient)
        self.assertEqual(client.base_url,'http://localhost:1234/v1')
        self.assertNotIn('Authorization',client._headers())
        self.assertEqual(_missing('custom',{'custom_base_url':cfg.custom_base_url}),'')
        self.assertIn('base_url',PROVIDER_FIELDS['custom'])
        self.assertEqual(_json_in('```json\n{"reply":"Готово"}\n```'),{'reply':'Готово'})

    def test_war_report_age_is_computed_from_russian_game_date(self):
        b=self.brain();b._war_state={'date':'1337.1.1'}
        self.assertGreater(b._war_age(Snapshot(date='1 марта 1337')),b.WAR_STANDING_FRESH_DAYS)


if __name__=='__main__': main()
