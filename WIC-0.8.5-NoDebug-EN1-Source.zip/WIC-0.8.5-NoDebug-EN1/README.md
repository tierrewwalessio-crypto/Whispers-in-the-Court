# Whispers in the Court 0.8.5 — NoDebug EN1

An English edition of the player's RU NoDebug fork, prepared for review by the
original author. The original mod, MIT license and author credits are retained.
The player's RU build remains separate and is not modified by preparing this package.

## Run the English edition

1. Close EU5 and any existing Court Brain window. Keep a separate save before trying
   another mod edition; a fresh disposable campaign is best for the first check.
2. Run `WhispersInTheCourt-0.8.5-NoDebug-EN1.exe` and choose **Open Court Brain**.
3. Configure your own AI provider. This edition starts with fresh settings: it does
   not import the RU player's keys, ChatGPT sign-in, instructions or campaign memory.
4. Use **Install mod** while EU5 is closed. Enable **WIC NoDebug 0.8.5 EN** in the
   launcher and disable every other Whispers in the Court edition.
5. Set EU5 to English for the English in-game interface. Start through Steam normally,
   with neither `-debug_mode` nor `-console` in the launch options. Leave Court Brain
   open while playing. The companion UI and default AI output language are English.

The original provider options, Russian support and the experimental ChatGPT option
are retained. No provider account is needed for the no-AI diagnostic below. Providers
require the player's own access; normal AI requests use their service's allowance.

## Independent paths

- Settings/account storage: `%LOCALAPPDATA%/WhispersInTheCourt-NoDebug085-EN/`.
- Mod: `Documents/Paradox Interactive/Europa Universalis V/mod/WhispersInTheCourtNoDebug085EN/`.
- Campaign memory/log: `Documents/Paradox Interactive/Europa Universalis V/court_brain_nodebug085_en/`.
- Poll file: `Documents/Paradox Interactive/Europa Universalis V/run/votc_nd85en_poll.txt`.

These are separate from the RU 0.8.5 paths. Only one companion/edition should run at
a time. To return to RU, close the game and EN companion, select the RU mod and run
its previous EXE with the appropriate saved game. EN memory is not merged back.

## Reproduce the transport without AI

Choose **Test events without AI** in the startup window:

1. Close the game and install the EN1 build from that diagnostic window.
2. Start a disposable English campaign with only this edition enabled and no debug flags.
3. Send long text. Check spaces, quotes, punctuation, paragraphs and the final
   **END OF LONG TEXT: everything arrived.** Close the event.
4. Replace it with short text. Check that no tail of the long message remains.
5. Show the test law and open the socio-economic laws window. Check **Grain Charter**,
   both options and their English descriptions. There is no need to enact it to check
   the text. It occupies custom law slot 1, so do not run this step in a valued campaign.
6. Tick only what you actually observed and save the diagnostic report.

The report records the received ACKs, debug/achievement flags and visual confirmations.
It does not claim a Steam achievement unlock. Test an ordinary achievement separately
if reproducing that result. The RU player has already reported one actual Steam unlock;
the newly packaged EN1 itself has not yet had a live campaign test.

## Build from source on Windows x64

Use Python with tkinter and SSL (the source requires Python 3.10 or newer). In the
source folder, create a virtual environment, activate it, then run:

```powershell
python -m pip install -r tools/court_brain/requirements.txt
python -m pip install pyinstaller
python -m unittest discover -s tools -p "test_*.py" -q
python tools/validate_mod.py
python tools/build_exe.py
```

The generated static localization and pinned librakaly DLL are already included.
Regenerating text expressions is optional: `python tools/gen_nodbg_text.py`. Preserve
the manifest's existing IDs. The build copies the original icon and mod into a single
EXE; users do not need Python installed separately.

Optional packaged checks (supply an absolute report path):

```powershell
.\dist\WhispersInTheCourt-0.8.5-NoDebug-EN1.exe --verify-build C:\Temp\wic-build.json
.\dist\WhispersInTheCourt-0.8.5-NoDebug-EN1.exe --verify-https C:\Temp\wic-https.json
```

The first is offline and uses a scratch mailbox. The second contacts a public Google
HTTPS endpoint without a key or inference request; an HTTP error such as 404 is an
expected valid TLS response. Neither installs the mod or changes real campaign data.

## Review material

Read `docs/NODEBUG-TECHNICAL-NOTES.md` for the mechanism, file map, evidence and limits.
`README-UPSTREAM.md` preserves the original author's instructions as historical
reference; its debug-mode advice does not describe this edition. The older RU readme
is likewise retained as history, not EN1 setup instructions. The handoff package also
contains a text diff, source archive, test summary, licenses and the supplied achievement
screenshot. No user configuration, API keys, authentication cache, saves or gameplay
logs are distributed.
